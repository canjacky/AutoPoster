plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.canjacky.autoposter"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.canjacky.autoposter"
        minSdk = 30
        targetSdk = 35
        versionCode = 280
        versionName = "2.8.0"
    }

    val ksPath = System.getenv("AUTPOSTER_KEYSTORE_PATH")
    val ksPass = System.getenv("AUTPOSTER_STORE_PASSWORD")
    val keyAliasEnv = System.getenv("AUTPOSTER_KEY_ALIAS")

    // Der AutoPoster-PKCS12-Schlüssel wurde absichtlich mit demselben
    // Passwort für Store und Private Key erstellt. Nur dieses bereits
    // erfolgreich geprüfte Store-Passwort verwenden. Damit kann ein
    // fehlerhaft kopiertes AUTPOSTER_KEY_PASSWORD-Secret den Build nicht
    // mehr beschädigen.
    signingConfigs {
        if (!ksPath.isNullOrBlank() && !ksPass.isNullOrBlank() && !keyAliasEnv.isNullOrBlank()) {
            create("releaseFromEnv") {
                storeFile = file(ksPath)
                storePassword = ksPass
                keyAlias = keyAliasEnv
                keyPassword = ksPass
            }
        }
    }

    buildTypes {
        debug {
            applicationIdSuffix = ".debug"
            versionNameSuffix = "-debug"
        }
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfigs.findByName("releaseFromEnv")?.let { signingConfig = it }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    // AGP 8+: BuildConfig explizit aktivieren, da die App VERSION_NAME verwendet.
    buildFeatures {
        buildConfig = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
}
