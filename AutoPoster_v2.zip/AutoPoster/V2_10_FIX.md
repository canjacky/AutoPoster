# AutoPoster v2.10.0

TikTok-Textfelder korrigiert:
- ACTION_SEND übergibt an TikTok nur noch das Medium, keinen kombinierten EXTRA_TEXT-Block.
- TIKTOK_TITLE wird separat in das TikTok-Titelfeld geschrieben.
- TIKTOK_DESC + TIKTOK_TAGS werden separat in das Beschreibungsfeld geschrieben.
- Titel und Beschreibung werden unabhängig verfolgt; Testmodus stoppt erst, wenn beide korrekt gefüllt wurden.
- Falls TikTok das Titelfeld zunächst nur als Platzhalter rendert, klickt AutoPoster den Titel-Platzhalter und versucht danach erneut das echte Eingabefeld.
- Diagnose protokolliert sichtbare EditText-Koordinaten/Hints, falls TikTok die UI erneut ändert.
