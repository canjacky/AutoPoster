# Build-Audit v2.0.0

Die bisherigen GitHub-Logs zeigten nacheinander drei unabhängige Build-Probleme:

1. Keystore-Base64 durch Copy/Paste beschädigt -> Workflow rekonstruiert nur den Keystore mit festem SHA-256.
2. BuildConfig nicht erzeugt -> `buildFeatures { buildConfig = true }`.
3. Separates KEY_PASSWORD-Secret verursachte `Password is not ASCII` -> vollständig entfernt.
   Der PKCS12-Key wurde mit demselben Passwort wie der Store erstellt, deshalb nutzt Gradle jetzt
   ausschließlich `AUTPOSTER_STORE_PASSWORD` für Store und Private Key.

Der Workflow prüft den privaten Schlüssel jetzt mit einem echten `jarsigner`-Signaturtest,
baut sauber mit `clean assembleRelease`, prüft die fertige APK mit `apksigner` und verifiziert
den erwarteten Zertifikat-SHA-256-Fingerprint.

Benötigte Secrets:
- AUTPOSTER_KEYSTORE_B64
- AUTPOSTER_STORE_PASSWORD
- AUTPOSTER_KEY_ALIAS

Ein vorhandenes AUTPOSTER_KEY_PASSWORD-Secret darf bestehen bleiben, wird aber nicht mehr verwendet.
