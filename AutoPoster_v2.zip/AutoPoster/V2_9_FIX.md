# AutoPoster v2.9

Fix for the Xiaomi/HyperOS Android share sheet shown as **Bild teilen**.

Deterministic flow:
1. Detect compact image-share resolver.
2. Click **Herunterladen** automatically.
3. Poll both Images and Downloads MediaStore for the original portrait.
4. If OEM MediaStore does not expose it, expand **Teilen über …** automatically.
5. Select **AutoPoster** when available and capture the original URI in ShareReceiverActivity.
6. Continue only when both original media and AUTOPOST metadata are present.

No user tap is required in the Android image-share sheet.
