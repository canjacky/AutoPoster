# AutoPoster v2.0

Android-Automation für ChatGPT -> TikTok -> Facebook -> YouTube Shorts.

## Was v2 gegenüber v1.x ändert

- Self-Healing Recovery Engine mit Watchdog statt starrer Klickfolge.
- Bildschirm-Fingerprints und lokaler Strategiespeicher: erfolgreiche Wiederherstellungswege werden für ähnliche Screens bevorzugt.
- Mehrere lokale Fallbacks für ChatGPT-Bildübernahme und Plattformnavigation.
- Experimenteller ChatGPT-Assist ohne OpenAI-API: Wenn lokale Recovery mehrfach scheitert, kann AutoPoster einen Screenshot mit einer strikt begrenzten Reparaturanfrage an die ChatGPT-App senden. Ausgeführt werden nur sichere Navigationsbefehle; kein beliebiger Code und kein finales Veröffentlichen durch den Reparaturplan.
- Ausführliches Diagnose-Protokoll.
- Signierter Release-Build für echte Android-Updates ohne wiederholtes Deinstallieren.
- In-App-Update-Prüfung über GitHub Releases. Android zeigt aus Sicherheitsgründen weiterhin den normalen Installieren/Aktualisieren-Dialog.

## Einmaliger Wechsel von v1.x auf v2

v1.x wurde als wechselnd signierter Debug-Build installiert. v2 verwendet einen festen privaten Release-Schlüssel. Deshalb ist voraussichtlich ein letztes Deinstallieren der alten v1.x notwendig. Danach werden v2.0 -> v2.1 -> v2.2 als normale Updates installiert, solange derselbe Release-Schlüssel verwendet wird.

## Signierung

Den privaten JKS-Schlüssel niemals in ein öffentliches Repository committen. In GitHub Actions werden vier Repository-Secrets verwendet:

- AUTPOSTER_KEYSTORE_B64
- AUTPOSTER_STORE_PASSWORD
- AUTPOSTER_KEY_ALIAS
- AUTPOSTER_KEY_PASSWORD

## Update-Mechanik

Die App prüft `canjacky/AutoPoster` auf das neueste GitHub Release und erwartet dort ein Asset `AutoPoster.apk`. Der Workflow `BUILD_WORKFLOW_V2.yml` baut die signierte APK und veröffentlicht/aktualisiert das passende Release.

## Sicherheitsmodell

Testmodus ist standardmäßig aktiv. Der ChatGPT-Recovery-Parser akzeptiert ausschließlich SCROLL_UP, SCROLL_DOWN, BACK, WAIT, TAP_TEXT und REOPEN_APP. Reparaturbefehle können weder beliebigen Code ausführen noch eigenständig einen finalen Social-Media-Post bestätigen.
