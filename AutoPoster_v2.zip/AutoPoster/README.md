# AutoPoster v2.1.0

Android-Automation für ChatGPT -> TikTok -> Facebook -> YouTube Shorts.

## Was v2 gegenüber v1.x ändert

- Self-Healing Recovery Engine mit Watchdog statt starrer Klickfolge.
- Bildschirm-Fingerprints und lokaler Strategiespeicher: erfolgreiche Wiederherstellungswege werden für ähnliche Screens bevorzugt.
- Mehrere lokale Fallbacks für ChatGPT-Bildübernahme und Plattformnavigation.
- Experimenteller ChatGPT-Assist ohne OpenAI-API: Wenn lokale Recovery mehrfach scheitert, kann AutoPoster einen Screenshot mit einer strikt begrenzten Reparaturanfrage an die ChatGPT-App senden. Ausgeführt werden nur sichere Navigationsbefehle; kein beliebiger Code und kein finales Veröffentlichen durch den Reparaturplan.
- Ausführliches Diagnose-Protokoll.
- Signierter Release-Build für echte Android-Updates ohne wiederholtes Deinstallieren.
- In-App-Update-Prüfung über GitHub Releases. Android zeigt aus Sicherheitsgründen weiterhin den normalen Installieren/Aktualisieren-Dialog.

## Einmaliger Wechsel von v1.x auf v2

v1.x wurde als wechselnd signierter Debug-Build installiert. v2 verwendet einen festen privaten Release-Schlüssel. Deshalb ist voraussichtlich ein letztes Deinstallieren der alten v1.x notwendig. Danach werden v2.0 -> v2.1 -> v2.2 als normale Updates installiert, solange derselbe Release-Schlüssel verwendet wird.

## Signierung

Den privaten JKS-Schlüssel niemals in ein öffentliches Repository committen. In GitHub Actions werden vier Repository-Secrets verwendet:

- AUTPOSTER_KEYSTORE_B64
- AUTPOSTER_STORE_PASSWORD
- AUTPOSTER_KEY_ALIAS
- AUTPOSTER_KEY_PASSWORD

## Update-Mechanik

Die App prüft `canjacky/AutoPoster` auf das neueste GitHub Release und erwartet dort ein Asset `AutoPoster.apk`. Der Workflow `BUILD_WORKFLOW_V2.yml` baut die signierte APK und veröffentlicht/aktualisiert das passende Release.

## Sicherheitsmodell

Testmodus ist standardmäßig aktiv. Der ChatGPT-Recovery-Parser akzeptiert ausschließlich SCROLL_UP, SCROLL_DOWN, BACK, WAIT, TAP_TEXT und REOPEN_APP. Reparaturbefehle können weder beliebigen Code ausführen noch eigenständig einen finalen Social-Media-Post bestätigen.


## v2.1
- Quellchat kann einmal als `AUTOPOSTER QUELLE` benannt werden; AutoPoster versucht ihn selbst über ChatGPT-Seitenleiste/Suche zu öffnen.
- Screenshots werden niemals mehr als Social-Media-Bild verwendet. Sie dienen nur zur Positions-/Fehleranalyse. AutoPoster öffnet das echte ChatGPT-Bild und wartet auf Download/Speichern.
- MediaStore filtert Screenshots/Bildschirmfotos explizit heraus.
- TikTok wartet mindestens 10 Sekunden auf die automatisch gewählte Musik und zusätzlich auf einen stabilen Editorzustand, bevor `Weiter` gedrückt wird.
- Testmodus stoppt weiterhin vor `Veröffentlichen`.


## v2.2.0
- Keine gecachten ChatGPT-Benachrichtigungs-Intents mehr: Quellchat wird aktiv navigiert.
- Fallback vom konfigurierten Quellchat auf `TikTok Content Maschine`.
- Generiertes Bild wird nur noch per visueller 9:16-Geometrie angetippt; keine generischen Image/Share-Nodes.
- `Link zum Chat teilen?` wird erkannt und sofort verworfen.
- Image-Viewer muss vor Download/Share verifiziert sein.
- Originalbild kann aus dem Image-Viewer direkt an AutoPoster geteilt werden.
- Harte Bildprüfung verhindert Upload von Handy-Screenshots.
- TikTok führt 18 Sekunden lang keinerlei automatische Aktion aus; Recovery darf die Musik-Wartezeit nicht umgehen.
