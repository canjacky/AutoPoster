# AutoPoster v2.6

Gezielter Fix für den echten Geräte-Log von v2.5:

- image viewer wird bereits erfolgreich erkannt.
- v2.5 wechselte danach auf WAIT_MEDIA und der globale Watchdog drückte nach 12s Back.
- v2.6 verbietet globale Recovery in WAIT_MEDIA vollständig.
- Der Download-Poller besitzt nun seinen eigenen Timeout.
- Wenn nach rund 10s kein gültiges Originalbild in MediaStore erscheint, bleibt der
  verifizierte Bildviewer offen und AutoPoster wechselt automatisch auf Image-Share.
- Download wird nicht endlos wiederholt.
- zusätzliche Fortschritts-/EventLog-Marker machen Download vs Share klar sichtbar.

Version 2.6.0 / versionCode 260.
