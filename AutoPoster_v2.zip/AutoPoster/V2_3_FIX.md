# AutoPoster v2.3 – Metadata-Scan-Fix

Behobener Fehler:
- v2.2 scrollte nach dem Öffnen des ChatGPT-Quellchats starr mehrfach hoch und danach wieder runter.
- Lange ChatGPT-Antworten werden in Android/Compose virtualisiert. Der komplette [AUTOPOST_V1]-Block ist deshalb nicht zwingend in einem einzigen Accessibility-Fenster vorhanden.
- v2.2 konnte außerdem Metadaten zu früh als gefunden markieren, obwohl nur ein Titel sichtbar war.

v2.3:
- springt zuerst einmal zum neuesten Ende des Quellchats,
- scannt danach nur noch in EINE Richtung nach oben,
- setzt sichtbare Textbereiche zu einem Metadaten-Transcript zusammen,
- akzeptiert Metadaten erst, wenn für alle aktivierten Plattformen Titel, Beschreibung und Tags vorhanden sind,
- stoppt den normalen Scanner statt endlos hoch/runter zu pendeln,
- übergibt danach an Recovery, falls der Block wirklich nicht gefunden werden kann.

Version: 2.3.0
