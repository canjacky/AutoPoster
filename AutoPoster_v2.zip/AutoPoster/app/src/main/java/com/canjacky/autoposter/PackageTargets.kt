package com.canjacky.autoposter

object PackageTargets {
    const val CHATGPT = "com.openai.chatgpt"
    const val TIKTOK = "com.zhiliaoapp.musically"
    const val FACEBOOK = "com.facebook.katana"
    const val YOUTUBE = "com.google.android.youtube"
}
