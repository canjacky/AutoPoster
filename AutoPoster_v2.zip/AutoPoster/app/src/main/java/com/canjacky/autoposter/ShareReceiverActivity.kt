package com.canjacky.autoposter

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import java.io.File

class ShareReceiverActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handle(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent != null) handle(intent)
    }

    private fun handle(i: Intent) {
        if (i.action != Intent.ACTION_SEND) { finish(); return }
        val uri = if (android.os.Build.VERSION.SDK_INT >= 33) {
            i.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
        } else {
            @Suppress("DEPRECATION") i.getParcelableExtra(Intent.EXTRA_STREAM)
        }
        val mime = i.type.orEmpty()
        if (uri == null || !(mime.startsWith("image/") || mime.startsWith("video/"))) {
            Prefs.setStatus(this, "ChatGPT hat Text statt Medien geteilt – versuche Bild/Video-Share.")
            finish(); return
        }

        try {
            val dir = File(cacheDir, "shared").apply { mkdirs() }
            val ext = if (mime.startsWith("video/")) "mp4" else "png"
            val out = File(dir, "latest_media.$ext")
            contentResolver.openInputStream(uri).use { input -> out.outputStream().use { output -> input?.copyTo(output) } }
            if (mime.startsWith("image/") && !ImageValidator.isValidPostingImage(out.absolutePath)) {
                val detail = ImageValidator.describe(out.absolutePath)
                out.delete()
                Prefs.setStage(this, Prefs.STAGE_CHATGPT)
                Prefs.setStatus(this, "Geteiltes Medium verworfen – kein gültiges Posting-Bild")
                Prefs.setDebug(this, "ShareReceiver Bildprüfung: $detail")
                finish()
                return
            }
            Prefs.setMedia(this, out.absolutePath, mime)
            Prefs.setStatus(this, if (Prefs.hasMetadata(this)) "Originalmedium übernommen. Starte Plattformen …" else "Originalmedium übernommen. Lese jetzt AUTOPOST-Metadaten …")
            PostingOrchestrator.afterMediaCaptured(this)
        } catch (e: Exception) {
            Prefs.setStatus(this, "Medium konnte nicht übernommen werden: ${e.message}")
        }
        finish()
    }
}
