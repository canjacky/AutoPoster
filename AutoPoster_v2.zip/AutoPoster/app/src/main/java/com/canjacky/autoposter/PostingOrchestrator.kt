package com.canjacky.autoposter

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.core.content.FileProvider
import java.io.File

object PostingOrchestrator {
    fun start(c: Context) {
        Prefs.bumpRunId(c)
        Prefs.setStatus(c, "Öffne den neuesten ChatGPT-Post …")
        Prefs.setStage(c, Prefs.STAGE_CHATGPT)
        EventLog.add(c, "FLOW", "ChatGPT öffnen")
        // Do not use a cached notification PendingIntent here. On the real device
        // it repeatedly reopened an arbitrary/stale conversation. Open ChatGPT
        // normally and let the accessibility service navigate to the source chat.
        launchPackage(c, PackageTargets.CHATGPT, "ChatGPT-App nicht gefunden")
    }

    fun afterMediaCaptured(c: Context) = next(c, after = null)

    fun next(c: Context, after: String?) {
        if (after == null && Prefs.isTikTok(c)) return launchTikTok(c)
        if ((after == null || after == Prefs.STAGE_TIKTOK) && Prefs.isFacebook(c)) return launchFacebook(c)
        if ((after == null || after == Prefs.STAGE_TIKTOK || after == Prefs.STAGE_FACEBOOK) && Prefs.isYouTube(c)) {
            val mime = Prefs.mediaMime(c)
            if (mime.startsWith("video/")) return launchYouTube(c, mediaUri(c))
            if (Prefs.useLatestMp4(c)) MediaStoreHelper.latestVideo(c)?.let { return launchYouTube(c, it) }
        }
        Prefs.setStage(c, Prefs.STAGE_DONE)
        Prefs.setStatus(c, "Fertig")
        Prefs.markProgress(c, "flow-done")
        EventLog.add(c, "DONE", "Alle aktivierten Plattformen abgeschlossen")
        launchHome(c)
    }

    private fun mediaUri(c: Context): Uri? {
        val p = Prefs.mediaPath(c)
        if (p.isBlank()) return null
        val f = File(p)
        if (!f.exists()) return null
        return try { FileProvider.getUriForFile(c, "${c.packageName}.fileprovider", f) }
        catch (e: Exception) { EventLog.add(c, "FAIL", "FileProvider: ${e.message}"); null }
    }

    private fun share(c: Context, pkg: String, uri: Uri?, mime: String, text: String): Boolean {
        if (uri == null) {
            Prefs.setStatus(c, "Keine Mediendatei verfügbar")
            EventLog.add(c, "FAIL", "Share zu $pkg: URI fehlt")
            return false
        }
        val i = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TEXT, text)
            clipData = android.content.ClipData.newRawUri("media", uri)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            setPackage(pkg)
        }
        return try {
            c.startActivity(i)
            Prefs.markProgress(c, "share:$pkg")
            EventLog.add(c, "FLOW", "Medium an $pkg übergeben")
            true
        } catch (e: Exception) {
            Prefs.setStatus(c, "App nicht geöffnet: $pkg")
            Prefs.setDebug(c, "ACTION_SEND: ${e.javaClass.simpleName}: ${e.message}")
            EventLog.add(c, "FAIL", "Share $pkg: ${e.message}")
            false
        }
    }

    private fun launchTikTok(c: Context) {
        val path = Prefs.mediaPath(c)
        if (Prefs.mediaMime(c).startsWith("image/") && !ImageValidator.isValidPostingImage(path)) {
            Prefs.setStage(c, Prefs.STAGE_CHATGPT)
            Prefs.setStatus(c, "Bildprüfung fehlgeschlagen – TikTok wird NICHT geöffnet")
            Prefs.setDebug(c, "Ungültiges Posting-Bild: ${ImageValidator.describe(path)}")
            EventLog.add(c, "FAIL", "TikTok blockiert: ungültiges Posting-Bild")
            return
        }
        Prefs.setStage(c, Prefs.STAGE_TIKTOK)
        Prefs.setStatus(c, "TikTok wird vorbereitet …")
        share(c, PackageTargets.TIKTOK, mediaUri(c), Prefs.mediaMime(c).ifBlank { "image/*" }, Prefs.metadata(c).tiktokText())
    }

    private fun launchFacebook(c: Context) {
        val path = Prefs.mediaPath(c)
        if (Prefs.mediaMime(c).startsWith("image/") && !ImageValidator.isValidPostingImage(path)) {
            Prefs.setStage(c, Prefs.STAGE_CHATGPT)
            Prefs.setStatus(c, "Bildprüfung fehlgeschlagen – Facebook wird NICHT geöffnet")
            Prefs.setDebug(c, "Ungültiges Posting-Bild: ${ImageValidator.describe(path)}")
            EventLog.add(c, "FAIL", "Facebook blockiert: ungültiges Posting-Bild")
            return
        }
        Prefs.setStage(c, Prefs.STAGE_FACEBOOK)
        Prefs.setStatus(c, "Facebook wird vorbereitet …")
        share(c, PackageTargets.FACEBOOK, mediaUri(c), Prefs.mediaMime(c).ifBlank { "image/*" }, Prefs.metadata(c).facebookText())
    }

    private fun launchYouTube(c: Context, uri: Uri?) {
        Prefs.setStage(c, Prefs.STAGE_YOUTUBE)
        Prefs.setStatus(c, "YouTube Short wird vorbereitet …")
        share(c, PackageTargets.YOUTUBE, uri, "video/*", Prefs.metadata(c).youtubeText())
    }

    fun finishPlatform(c: Context, stage: String) {
        Prefs.markProgress(c, "$stage-final-trigger")
        Handler(Looper.getMainLooper()).postDelayed({ next(c, stage) }, 5000)
    }

    private fun launchPackage(c: Context, pkg: String, failure: String) {
        c.packageManager.getLaunchIntentForPackage(pkg)?.let {
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            c.startActivity(it)
        } ?: run { Prefs.setStatus(c, failure); EventLog.add(c, "FAIL", failure) }
    }

    private fun launchHome(c: Context) {
        c.packageManager.getLaunchIntentForPackage(c.packageName)?.apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            c.startActivity(this)
        }
    }
}
