package com.canjacky.autoposter

import android.app.PendingIntent
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class ChatGptNotificationListener : NotificationListenerService() {
    companion object {
        @Volatile var latestChatGptIntent: PendingIntent? = null
        @Volatile var latestChatGptTitle: String = ""
        @Volatile var latestPostedAt: Long = 0L
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        try {
            activeNotifications
                ?.filter { it.packageName == PackageTargets.CHATGPT }
                ?.maxByOrNull { it.postTime }
                ?.let { remember(it) }
        } catch (_: Exception) { }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn?.packageName != PackageTargets.CHATGPT) return
        remember(sbn)
    }

    private fun remember(sbn: StatusBarNotification) {
        latestChatGptIntent = sbn.notification.contentIntent
        latestChatGptTitle = sbn.notification.extras?.getCharSequence("android.title")?.toString().orEmpty()
        latestPostedAt = sbn.postTime
    }
}
