package com.canjacky.autoposter

import android.content.Context
import java.security.MessageDigest

object StrategyMemory {
    private const val PREF = "autoposter_strategy_memory"
    private fun p(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)
    private fun key(pkg: String, stage: String, fingerprint: String): String {
        val raw = "$pkg|$stage|$fingerprint"
        val hash = MessageDigest.getInstance("SHA-256").digest(raw.toByteArray()).take(8).joinToString("") { "%02x".format(it) }
        return "s_$hash"
    }
    fun remember(c: Context, pkg: String, stage: String, fingerprint: String, strategy: String) {
        if (fingerprint.isBlank()) return
        p(c).edit().putString(key(pkg, stage, fingerprint), strategy).apply()
        EventLog.add(c, "LEARN", "$stage/$pkg → $strategy")
    }
    fun preferred(c: Context, pkg: String, stage: String, fingerprint: String): String? =
        p(c).getString(key(pkg, stage, fingerprint), null)
}
