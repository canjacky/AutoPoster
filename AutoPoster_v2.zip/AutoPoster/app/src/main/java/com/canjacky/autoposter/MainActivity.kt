package com.canjacky.autoposter

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var log: TextView
    private lateinit var sourceChat: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildUi())
        requestNeededPermissions()
        checkUpdateOnStart()
    }

    override fun onResume() {
        super.onResume(); refreshStatus()
    }

    private fun refreshStatus() {
        if (::status.isInitialized) {
            status.text = buildString {
                append("Status: ").append(Prefs.getStatus(this@MainActivity))
                append("\nStufe: ").append(Prefs.getStage(this@MainActivity))
                append("\nLetzte App: ").append(Prefs.lastPackage(this@MainActivity).ifBlank { "–" })
                append("\nLetzter Fortschritt: ").append(Prefs.lastProgressReason(this@MainActivity).ifBlank { "–" })
                append("\nRecovery-Runde: ").append(Prefs.recoveryRound(this@MainActivity))
                append("\nFingerprint: ").append(Prefs.screenFingerprint(this@MainActivity).take(80).ifBlank { "–" })
                append("\nDiagnose: ").append(Prefs.debug(this@MainActivity).ifBlank { "–" })
            }
        }
        if (::log.isInitialized) log.text = EventLog.text(this).ifBlank { "Noch kein Lauf." }
    }

    private fun buildUi(): ScrollView {
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 40, 40, 48) }
        scroll.addView(box)

        box.addView(TextView(this).apply {
            text = "AUTOPOSTER v${BuildConfig.VERSION_NAME}"
            textSize = 30f; setTextColor(Color.BLACK)
        })
        box.addView(TextView(this).apply {
            text = "Self-Healing Engine • ChatGPT → TikTok → Facebook → YouTube"
            textSize = 15f; setPadding(0, 4, 0, 22)
        })

        fun toggle(label: String, checked: Boolean, change: (Boolean)->Unit) = CheckBox(this).apply {
            text = label; isChecked = checked; setOnCheckedChangeListener { _, v -> change(v) }
        }
        box.addView(toggle("Testmodus – vor finalem Veröffentlichen stoppen", Prefs.isTestMode(this)) { Prefs.setTestMode(this, it) })
        box.addView(toggle("Automatische Recovery Engine", Prefs.isAutoRecovery(this)) { Prefs.setAutoRecovery(this, it) })
        box.addView(toggle("ChatGPT Assist als letzter Fallback (experimentell, keine API)", Prefs.isAiAssist(this)) { Prefs.setAiAssist(this, it) })
        box.addView(toggle("TikTok", Prefs.isTikTok(this)) { Prefs.setTikTok(this, it) })
        box.addView(toggle("Facebook", Prefs.isFacebook(this)) { Prefs.setFacebook(this, it) })
        box.addView(toggle("YouTube Shorts", Prefs.isYouTube(this)) { Prefs.setYouTube(this, it) })
        box.addView(toggle("Für YouTube neuestes MP4 vom Handy verwenden", Prefs.useLatestMp4(this)) { Prefs.setLatestMp4(this, it) })

        box.addView(TextView(this).apply {
            text = "ChatGPT-Quellchat (einmal genau so umbenennen)"
            textSize = 13f; setPadding(0, 18, 0, 4)
        })
        sourceChat = EditText(this).apply {
            setText(Prefs.sourceChatName(this@MainActivity))
            hint = "AUTOPOSTER QUELLE"
            isSingleLine = true
            setOnFocusChangeListener { _, hasFocus ->
                if (!hasFocus) Prefs.setSourceChatName(this@MainActivity, text.toString())
            }
        }
        box.addView(sourceChat, params())

        status = TextView(this).apply { textSize = 14f; setPadding(0, 24, 0, 16) }
        box.addView(status)

        box.addView(Button(this).apply { text = "JETZT POSTEN"; textSize = 21f; setOnClickListener { Prefs.setSourceChatName(this@MainActivity, sourceChat.text.toString()); PostingOrchestrator.start(this@MainActivity); refreshStatus() } }, params(86))
        box.addView(Button(this).apply { text = "STATUS AKTUALISIEREN"; setOnClickListener { refreshStatus() } }, params())
        box.addView(Button(this).apply { text = "BEDIENUNGSHILFE"; setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } }, params())
        box.addView(Button(this).apply { text = "CHATGPT-BENACHRICHTIGUNGEN"; setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) } }, params())
        box.addView(Button(this).apply {
            text = "UPDATE PRÜFEN"
            setOnClickListener {
                text = "PRÜFE …"
                GitHubUpdater.checkAsync(this@MainActivity) { r ->
                    text = "UPDATE PRÜFEN"
                    Toast.makeText(this@MainActivity, r.message, Toast.LENGTH_LONG).show()
                    if (r.available) {
                        AlertDialog.Builder(this@MainActivity)
                            .setTitle("AutoPoster ${r.version}")
                            .setMessage("Neue signierte Version verfügbar. Herunterladen und Android-Update öffnen?")
                            .setPositiveButton("Update") { _, _ -> GitHubUpdater.downloadAndInstall(this@MainActivity, r.assetUrl) { msg -> Prefs.setStatus(this@MainActivity, msg); refreshStatus() } }
                            .setNegativeButton("Später", null).show()
                    }
                }
            }
        }, params())
        box.addView(Button(this).apply {
            text = "INSTALLATIONSRECHT FÜR UPDATES"
            setOnClickListener {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
                }
            }
        }, params())
        box.addView(Button(this).apply {
            text = "LAUF ZURÜCKSETZEN"
            setOnClickListener { Prefs.bumpRunId(this@MainActivity); Prefs.setStage(this@MainActivity, Prefs.STAGE_IDLE); Prefs.setStatus(this@MainActivity, "Bereit"); refreshStatus() }
        }, params())

        box.addView(TextView(this).apply { text = "Diagnose-Protokoll"; textSize = 18f; setPadding(0, 28, 0, 8) })
        log = TextView(this).apply { textSize = 12f; setTextIsSelectable(true); setPadding(14, 14, 14, 14); setBackgroundColor(0xffeeeeee.toInt()) }
        box.addView(log, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        box.addView(TextView(this).apply {
            text = "V2 arbeitet zustandsbasiert: Wenn ein Schritt hängen bleibt, probiert die Recovery Engine alternative Wege, merkt sich erfolgreiche Strategien pro Bildschirm und kann als letzten Fallback einen Screenshot samt strukturierter Reparaturanfrage an ChatGPT senden. ChatGPT-Kommandos sind auf sichere Navigationsaktionen begrenzt."
            textSize = 12f; setPadding(0, 22, 0, 0)
        })
        return scroll
    }

    private fun params(h: Int = 64) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h.dp()).apply {
        setMargins(0, 6.dp(), 0, 6.dp()); gravity = Gravity.CENTER_HORIZONTAL
    }
    private fun Int.dp() = (this * resources.displayMetrics.density).toInt()

    private fun checkUpdateOnStart() {
        GitHubUpdater.checkAsync(this) { r ->
            if (r.available && !isFinishing) {
                Prefs.setStatus(this, "Update ${r.version} verfügbar")
                AlertDialog.Builder(this)
                    .setTitle("AutoPoster ${r.version} verfügbar")
                    .setMessage("Herunterladen und als normales Android-Update installieren?")
                    .setPositiveButton("Update") { _, _ -> GitHubUpdater.downloadAndInstall(this, r.assetUrl) { msg -> Prefs.setStatus(this, msg); refreshStatus() } }
                    .setNegativeButton("Später", null)
                    .show()
            }
        }
    }

    private fun requestNeededPermissions() {
        val req = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) req += Manifest.permission.POST_NOTIFICATIONS
            if (checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES) != PackageManager.PERMISSION_GRANTED) req += Manifest.permission.READ_MEDIA_IMAGES
            if (checkSelfPermission(Manifest.permission.READ_MEDIA_VIDEO) != PackageManager.PERMISSION_GRANTED) req += Manifest.permission.READ_MEDIA_VIDEO
        } else if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) req += Manifest.permission.READ_EXTERNAL_STORAGE
        if (req.isNotEmpty()) requestPermissions(req.toTypedArray(), 100)
    }
}
