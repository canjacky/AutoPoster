package com.canjacky.autoposter

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File

object ChatGptRepairBridge {
    fun launch(c: Context, screenshot: File?, stage: String, fingerprint: String, diagnostic: String): Boolean {
        val prompt = buildString {
            append("Du hilfst einer Android-Automation, die in einer Social-App festhängt. ")
            append("Analysiere ausschließlich den aktuellen Bildschirm und gib höchstens 6 sichere Navigationsbefehle zurück. ")
            append("Keine Anmeldedaten, keine Käufe, keine Löschaktionen und NICHT selbst veröffentlichen. ")
            append("Antwort exakt in diesem Format:\n[AUTOFIX_V1]\n")
            append("Erlaubt: SCROLL_UP, SCROLL_DOWN, BACK, WAIT=1..10, TAP_TEXT=..., REOPEN_APP=chatgpt|tiktok|facebook|youtube\n")
            append("[/AUTOFIX_V1]\n")
            append("Stufe=$stage\nFingerprint=$fingerprint\nDiagnose=$diagnostic")
        }
        val i = Intent(Intent.ACTION_SEND).apply {
            setPackage(PackageTargets.CHATGPT)
            type = if (screenshot != null && screenshot.exists()) "image/png" else "text/plain"
            putExtra(Intent.EXTRA_TEXT, prompt)
            if (screenshot != null && screenshot.exists()) {
                val uri: Uri = FileProvider.getUriForFile(c, "${c.packageName}.fileprovider", screenshot)
                putExtra(Intent.EXTRA_STREAM, uri)
                clipData = android.content.ClipData.newRawUri("repair", uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try { c.startActivity(i); true } catch (_: Exception) { false }
    }
}
