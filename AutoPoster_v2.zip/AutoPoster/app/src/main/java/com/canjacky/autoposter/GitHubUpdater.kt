package com.canjacky.autoposter

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

object GitHubUpdater {
    data class Result(val available: Boolean, val version: String = "", val message: String = "", val assetUrl: String = "")
    private const val API = "https://api.github.com/repos/canjacky/AutoPoster/releases/latest"

    fun checkAsync(c: Context, callback: (Result) -> Unit) {
        Thread {
            val r = try { check() } catch (e: Exception) { Result(false, message = "Update-Prüfung fehlgeschlagen: ${e.message}") }
            Handler(Looper.getMainLooper()).post { callback(r) }
        }.start()
    }

    private fun check(): Result {
        val conn = (URL(API).openConnection() as HttpURLConnection).apply {
            connectTimeout = 8000; readTimeout = 8000
            setRequestProperty("Accept", "application/vnd.github+json")
            setRequestProperty("User-Agent", "AutoPoster/${BuildConfig.VERSION_NAME}")
        }
        val body = conn.inputStream.bufferedReader().use { it.readText() }
        val j = JSONObject(body)
        val tag = j.optString("tag_name").removePrefix("v")
        val assets = j.optJSONArray("assets")
        var url = ""
        if (assets != null) for (i in 0 until assets.length()) {
            val a = assets.getJSONObject(i)
            val name = a.optString("name")
            if (name.equals("AutoPoster.apk", true) || name.endsWith("release.apk", true)) {
                url = a.optString("browser_download_url"); break
            }
        }
        val newer = compareSemver(tag, BuildConfig.VERSION_NAME.removeSuffix("-debug")) > 0
        return if (newer && url.isNotBlank()) Result(true, tag, "AutoPoster $tag verfügbar", url)
        else Result(false, tag, "AutoPoster ist aktuell")
    }

    fun downloadAndInstall(c: Context, assetUrl: String, callback: (String) -> Unit) {
        Thread {
            try {
                val dir = File(c.cacheDir, "updates").apply { mkdirs() }
                val out = File(dir, "AutoPoster-update.apk")
                val conn = (URL(assetUrl).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 12000; readTimeout = 30000
                    instanceFollowRedirects = true
                    setRequestProperty("User-Agent", "AutoPoster/${BuildConfig.VERSION_NAME}")
                }
                conn.inputStream.use { input -> out.outputStream().use { input.copyTo(it) } }
                Handler(Looper.getMainLooper()).post {
                    callback("Update geladen – Android-Installer wird geöffnet")
                    val uri = FileProvider.getUriForFile(c, "${c.packageName}.fileprovider", out)
                    val i = Intent(Intent.ACTION_VIEW).apply {
                        setDataAndType(uri, "application/vnd.android.package-archive")
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    c.startActivity(i)
                }
            } catch (e: Exception) {
                Handler(Looper.getMainLooper()).post { callback("Update-Download fehlgeschlagen: ${e.message}") }
            }
        }.start()
    }

    private fun compareSemver(a: String, b: String): Int {
        val aa = a.split('.').map { it.takeWhile { ch -> ch.isDigit() }.toIntOrNull() ?: 0 }
        val bb = b.split('.').map { it.takeWhile { ch -> ch.isDigit() }.toIntOrNull() ?: 0 }
        for (i in 0 until maxOf(aa.size, bb.size)) {
            val x = aa.getOrElse(i) { 0 }; val y = bb.getOrElse(i) { 0 }
            if (x != y) return x.compareTo(y)
        }
        return 0
    }
}
