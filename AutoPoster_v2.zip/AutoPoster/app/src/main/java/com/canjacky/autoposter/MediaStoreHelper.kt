package com.canjacky.autoposter

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import java.io.File

object MediaStoreHelper {
    fun latestVideo(c: Context): Uri? {
        val projection = arrayOf(MediaStore.Video.Media._ID)
        val sort = "${MediaStore.Video.Media.DATE_ADDED} DESC"
        c.contentResolver.query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, projection, null, null, sort)?.use { cur ->
            if (cur.moveToFirst()) {
                val id = cur.getLong(cur.getColumnIndexOrThrow(MediaStore.Video.Media._ID))
                return ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id)
            }
        }
        return null
    }

    data class RecentImage(val uri: Uri, val mime: String, val name: String, val relativePath: String)

    /**
     * Find a newly downloaded/generated image, but NEVER use Android screenshots as
     * social media. Screenshots are allowed only for diagnostics/recovery.
     */
    fun latestRealImageAfter(c: Context, afterMillis: Long): RecentImage? {
        val projection = arrayOf(
            MediaStore.Images.Media._ID,
            MediaStore.Images.Media.DATE_ADDED,
            MediaStore.Images.Media.DISPLAY_NAME,
            MediaStore.Images.Media.RELATIVE_PATH,
            MediaStore.Images.Media.MIME_TYPE,
            MediaStore.Images.Media.WIDTH,
            MediaStore.Images.Media.HEIGHT
        )
        val sort = "${MediaStore.Images.Media.DATE_ADDED} DESC"
        c.contentResolver.query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection, null, null, sort)?.use { cur ->
            val idCol = cur.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
            val dateCol = cur.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED)
            val nameCol = cur.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
            val pathCol = cur.getColumnIndexOrThrow(MediaStore.Images.Media.RELATIVE_PATH)
            val mimeCol = cur.getColumnIndexOrThrow(MediaStore.Images.Media.MIME_TYPE)
            val widthCol = cur.getColumnIndexOrThrow(MediaStore.Images.Media.WIDTH)
            val heightCol = cur.getColumnIndexOrThrow(MediaStore.Images.Media.HEIGHT)
            var checked = 0
            while (cur.moveToNext() && checked++ < 30) {
                val addedMs = cur.getLong(dateCol) * 1000L
                if (addedMs < afterMillis - 4_000L) break
                val name = cur.getString(nameCol).orEmpty()
                val rel = cur.getString(pathCol).orEmpty()
                val mime = cur.getString(mimeCol).orEmpty().ifBlank { "image/jpeg" }
                val width = cur.getInt(widthCol)
                val height = cur.getInt(heightCol)
                val marker = "$name $rel".lowercase()
                if (marker.contains("screenshot") || marker.contains("screenshots") || marker.contains("bildschirmfoto") || marker.contains("bildschirmfotos")) continue
                if (width < 300 || height < 400) continue
                val id = cur.getLong(idCol)
                return RecentImage(ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id), mime, name, rel)
            }
        }
        return null
    }

    fun copyToCache(c: Context, uri: Uri, mime: String = "image/jpeg"): String? {
        return try {
            val dir = File(c.cacheDir, "shared").apply { mkdirs() }
            val ext = when {
                mime.contains("png", true) -> "png"
                mime.startsWith("video/") -> "mp4"
                else -> "jpg"
            }
            val out = File(dir, "latest_media.$ext")
            c.contentResolver.openInputStream(uri).use { input ->
                if (input == null) return null
                out.outputStream().use { output -> input.copyTo(output) }
            }
            out.absolutePath
        } catch (_: Exception) { null }
    }
}
