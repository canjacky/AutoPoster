package com.canjacky.autoposter

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import java.io.File

object MediaStoreHelper {
    fun latestVideo(c: Context): Uri? {
        val projection = arrayOf(MediaStore.Video.Media._ID)
        val sort = "${MediaStore.Video.Media.DATE_ADDED} DESC"
        c.contentResolver.query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, projection, null, null, sort)?.use { cur ->
            if (cur.moveToFirst()) {
                val id = cur.getLong(cur.getColumnIndexOrThrow(MediaStore.Video.Media._ID))
                return ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id)
            }
        }
        return null
    }

    fun latestImageAfter(c: Context, afterMillis: Long): Uri? {
        val projection = arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.DATE_ADDED)
        val sort = "${MediaStore.Images.Media.DATE_ADDED} DESC"
        c.contentResolver.query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection, null, null, sort)?.use { cur ->
            if (cur.moveToFirst()) {
                val addedSeconds = cur.getLong(cur.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED))
                if (addedSeconds * 1000L >= afterMillis - 5_000L) {
                    val id = cur.getLong(cur.getColumnIndexOrThrow(MediaStore.Images.Media._ID))
                    return ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id)
                }
            }
        }
        return null
    }

    fun copyToCache(c: Context, uri: Uri, mime: String = "image/jpeg"): String? {
        return try {
            val dir = File(c.cacheDir, "shared").apply { mkdirs() }
            val ext = when {
                mime.contains("png", true) -> "png"
                mime.startsWith("video/") -> "mp4"
                else -> "jpg"
            }
            val out = File(dir, "latest_media.$ext")
            c.contentResolver.openInputStream(uri).use { input ->
                if (input == null) return null
                out.outputStream().use { output -> input.copyTo(output) }
            }
            out.absolutePath
        } catch (_: Exception) { null }
    }
}
