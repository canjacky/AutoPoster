package com.canjacky.autoposter

object MetadataParser {
    private fun extract(text: String, tag: String): String {
        val r = Regex("\\[$tag](.*?)\\[/$tag]", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE))
        return r.find(text)?.groupValues?.getOrNull(1)?.trim().orEmpty()
    }

    fun parse(text: String): PostMetadata? {
        if (!text.contains("[AUTOPOST_V1]", ignoreCase = true)) return null
        val m = PostMetadata(
            tiktokTitle = extract(text, "TIKTOK_TITLE"),
            tiktokDesc = extract(text, "TIKTOK_DESC"),
            tiktokTags = extract(text, "TIKTOK_TAGS"),
            facebookTitle = extract(text, "FACEBOOK_TITLE"),
            facebookDesc = extract(text, "FACEBOOK_DESC"),
            facebookTags = extract(text, "FACEBOOK_TAGS"),
            youtubeTitle = extract(text, "YOUTUBE_TITLE"),
            youtubeDesc = extract(text, "YOUTUBE_DESC"),
            youtubeTags = extract(text, "YOUTUBE_TAGS")
        )
        return if (m.tiktokTitle.isNotBlank() || m.facebookTitle.isNotBlank()) m else null
    }
}
