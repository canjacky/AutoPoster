package com.canjacky.autoposter

object MetadataParser {
    private fun extract(text: String, tag: String): String {
        val r = Regex("\\[$tag](.*?)\\[/$tag]", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE))
        return r.find(text)?.groupValues?.getOrNull(1)?.trim().orEmpty()
    }

    fun parse(text: String): PostMetadata? {
        if (!text.contains("[AUTOPOST_V1]", ignoreCase = true)) return null
        val m = PostMetadata(
            tiktokTitle = extract(text, "TIKTOK_TITLE"),
            tiktokDesc = extract(text, "TIKTOK_DESC"),
            tiktokTags = extract(text, "TIKTOK_TAGS"),
            facebookTitle = extract(text, "FACEBOOK_TITLE"),
            facebookDesc = extract(text, "FACEBOOK_DESC"),
            facebookTags = extract(text, "FACEBOOK_TAGS"),
            youtubeTitle = extract(text, "YOUTUBE_TITLE"),
            youtubeDesc = extract(text, "YOUTUBE_DESC"),
            youtubeTags = extract(text, "YOUTUBE_TAGS")
        )
        return if (
            m.tiktokTitle.isNotBlank() || m.facebookTitle.isNotBlank() || m.youtubeTitle.isNotBlank()
        ) m else null
    }

    /**
     * V2.3: Do not declare metadata "found" from one visible viewport just because
     * a title happened to be present. ChatGPT virtualizes long responses, so the
     * title/description/tags can live on different accessibility screens.
     */
    fun isCompleteForEnabledPlatforms(
        m: PostMetadata,
        tiktok: Boolean,
        facebook: Boolean,
        youtube: Boolean
    ): Boolean {
        fun complete(a: String, b: String, c: String) =
            a.isNotBlank() && b.isNotBlank() && c.isNotBlank()

        val tt = !tiktok || complete(m.tiktokTitle, m.tiktokDesc, m.tiktokTags)
        val fb = !facebook || complete(m.facebookTitle, m.facebookDesc, m.facebookTags)
        val yt = !youtube || complete(m.youtubeTitle, m.youtubeDesc, m.youtubeTags)
        return tt && fb && yt && (tiktok || facebook || youtube)
    }

    fun parseComplete(
        text: String,
        tiktok: Boolean,
        facebook: Boolean,
        youtube: Boolean
    ): PostMetadata? = parse(text)?.takeIf {
        isCompleteForEnabledPlatforms(it, tiktok, facebook, youtube)
    }
}
