package com.canjacky.autoposter

object SafeAutofix {
    sealed class Command {
        data object ScrollUp : Command()
        data object ScrollDown : Command()
        data object Back : Command()
        data class Wait(val seconds: Int) : Command()
        data class TapText(val text: String) : Command()
        data class Reopen(val target: String) : Command()
    }

    fun parse(text: String): List<Command> {
        val block = Regex("\\[AUTOFIX_V1](.*?)\\[/AUTOFIX_V1]", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE))
            .find(text)?.groupValues?.getOrNull(1) ?: return emptyList()
        return block.lines().mapNotNull { raw ->
            val line = raw.trim()
            when {
                line.equals("SCROLL_UP", true) -> Command.ScrollUp
                line.equals("SCROLL_DOWN", true) -> Command.ScrollDown
                line.equals("BACK", true) -> Command.Back
                line.startsWith("WAIT=", true) -> line.substringAfter('=').toIntOrNull()?.coerceIn(1, 10)?.let { Command.Wait(it) }
                line.startsWith("TAP_TEXT=", true) -> line.substringAfter('=').trim().takeIf { it.isNotBlank() && it.length <= 50 }?.let { Command.TapText(it) }
                line.startsWith("REOPEN_APP=", true) -> line.substringAfter('=').trim().lowercase().takeIf { it in setOf("chatgpt","tiktok","facebook","youtube") }?.let { Command.Reopen(it) }
                else -> null
            }
        }.take(6)
    }
}
