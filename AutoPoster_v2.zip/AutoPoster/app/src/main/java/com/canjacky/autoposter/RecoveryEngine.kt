package com.canjacky.autoposter

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.view.accessibility.AccessibilityNodeInfo

class RecoveryEngine(private val service: AccessibilityService) {
    data class ContextSnapshot(val stage: String, val pkg: String, val text: String, val fingerprint: String)

    fun chooseOrder(c: Context, s: ContextSnapshot): List<String> {
        val base = when (s.stage) {
            Prefs.STAGE_CHATGPT -> listOf("chat-scroll-up", "chat-scroll-down", "chat-reopen")
            Prefs.STAGE_TIKTOK, Prefs.STAGE_FACEBOOK, Prefs.STAGE_YOUTUBE -> listOf("platform-next", "platform-scroll", "platform-reopen")
            else -> listOf("back", "reopen")
        }
        val preferred = StrategyMemory.preferred(c, s.pkg, s.stage, s.fingerprint)
        return if (preferred != null && preferred in base) listOf(preferred) + base.filterNot { it == preferred } else base
    }

    fun reopen(targetPkg: String): Boolean {
        val i = service.packageManager.getLaunchIntentForPackage(targetPkg) ?: return false
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        return try { service.startActivity(i); true } catch (_: Exception) { false }
    }

    fun scroll(root: AccessibilityNodeInfo?, forward: Boolean): Boolean {
        if (root == null) return false
        val action = if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        val nodes = mutableListOf<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            if (n.isScrollable) nodes += n
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return nodes.asReversed().any { it.performAction(action) }
    }
}
