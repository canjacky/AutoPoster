package com.canjacky.autoposter

data class PostMetadata(
    val tiktokTitle: String = "",
    val tiktokDesc: String = "",
    val tiktokTags: String = "",
    val facebookTitle: String = "",
    val facebookDesc: String = "",
    val facebookTags: String = "",
    val youtubeTitle: String = "",
    val youtubeDesc: String = "",
    val youtubeTags: String = ""
) {
    fun tiktokText(): String = listOf(tiktokTitle, tiktokDesc, tiktokTags).filter { it.isNotBlank() }.joinToString("\n\n")
    fun facebookText(): String = listOf(facebookTitle, facebookDesc, facebookTags).filter { it.isNotBlank() }.joinToString("\n\n")
    fun youtubeText(): String {
        val base = listOf(youtubeTitle, youtubeTags).filter { it.isNotBlank() }.joinToString(" ").replace("\n", " ").trim()
        return if (base.length <= 100) base else base.take(97).trimEnd() + "..."
    }
}
