package com.canjacky.autoposter

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object EventLog {
    private const val PREF = "autoposter_v2_log"
    private const val KEY = "lines"
    private const val MAX = 80
    private fun p(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    @Synchronized fun add(c: Context, type: String, message: String) {
        val fmt = SimpleDateFormat("HH:mm:ss", Locale.GERMANY)
        val line = "${fmt.format(Date())} [$type] ${message.replace('\n',' ')}"
        val old = p(c).getString(KEY, "").orEmpty().lines().filter { it.isNotBlank() }.toMutableList()
        old += line
        while (old.size > MAX) old.removeAt(0)
        p(c).edit().putString(KEY, old.joinToString("\n")).apply()
    }
    fun text(c: Context) = p(c).getString(KEY, "").orEmpty()
    fun clear(c: Context) = p(c).edit().remove(KEY).apply()
}
