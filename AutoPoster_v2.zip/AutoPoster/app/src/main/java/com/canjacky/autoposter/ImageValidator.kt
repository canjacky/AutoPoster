package com.canjacky.autoposter

import android.graphics.BitmapFactory
import java.io.File

/** Hard stop against accidentally uploading a phone screenshot or invalid cache file. */
object ImageValidator {
    data class Info(val ok: Boolean, val width: Int, val height: Int, val reason: String)

    fun inspect(path: String): Info {
        if (path.isBlank()) return Info(false, 0, 0, "Pfad leer")
        val f = File(path)
        if (!f.exists() || !f.isFile || f.length() < 20_000L) return Info(false, 0, 0, "Datei fehlt/zu klein")
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.absolutePath, o)
        val w = o.outWidth
        val h = o.outHeight
        if (w < 300 || h < 500) return Info(false, w, h, "Auflösung zu klein")
        if (h <= w) return Info(false, w, h, "nicht Hochformat")
        val ratio = w.toFloat() / h.toFloat()
        // Generated task artwork is 9:16-ish. A modern phone screenshot such as
        // 690x1536 has ratio 0.449 and is intentionally rejected. Also allow 2:3.
        if (ratio !in 0.50f..0.72f) return Info(false, w, h, "Seitenverhältnis $ratio nicht 9:16/2:3")
        return Info(true, w, h, "OK")
    }

    fun isValidPostingImage(path: String): Boolean = inspect(path).ok
    fun describe(path: String): String {
        val i = inspect(path)
        return "${i.width}x${i.height}; ${i.reason}"
    }
}
