package com.canjacky.autoposter

import android.accessibilityservice.AccessibilityService
import android.graphics.Bitmap
import android.graphics.Rect
import android.graphics.Path
import android.accessibilityservice.GestureDescription
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import java.security.MessageDigest
import java.io.File
import java.io.FileOutputStream

class AutoPosterAccessibilityService : AccessibilityService() {
    private val h = Handler(Looper.getMainLooper())
    private var lastActionAt = 0L
    private var observedRunId = -1L
    private var captureInFlight = false
    private var fallbackImageOpened = false
    private var fallbackSaveRequested = false
    private var downloadPollStarted = false
    private var platformCaptionFilled = false
    private var platformFinalClicked = false
    private var metadataScrollAttempts = 0
    private var imageScrollAttempts = 0
    private var captureFailures = 0
    private var lastToast = ""
    private var lastToastAt = 0L
    private lateinit var recoveryEngine: RecoveryEngine
    private var lastRecoveryAt = 0L
    private var aiRequestSent = false
    private var aiSendClicked = false
    private var aiScreenshot: File? = null

    // V2.1 source-chat navigation and TikTok editor pacing.
    private var sourceNavState = 0
    private var sourceNavLastAt = 0L
    private var saveRequestedAt = 0L
    private var tiktokEnteredAt = 0L
    private var tiktokAdvanceCount = 0
    private var tiktokLastAdvanceAt = 0L
    private var tiktokStableFp = ""
    private var tiktokStableSince = 0L

    private val platformPoll = object : Runnable {
        override fun run() {
            try {
                when (Prefs.getStage(this@AutoPosterAccessibilityService)) {
                    Prefs.STAGE_TIKTOK -> handlePlatform(Prefs.STAGE_TIKTOK, Prefs.metadata(this@AutoPosterAccessibilityService).tiktokText(), listOf("Posten", "Post", "Veröffentlichen", "Publish"))
                    Prefs.STAGE_FACEBOOK -> handlePlatform(Prefs.STAGE_FACEBOOK, Prefs.metadata(this@AutoPosterAccessibilityService).facebookText(), listOf("Posten", "Post", "Veröffentlichen", "Publish"))
                    Prefs.STAGE_YOUTUBE -> handleYouTube()
                }
            } catch (e: Exception) {
                Prefs.setDebug(this@AutoPosterAccessibilityService, "Platform-Poll: ${e.javaClass.simpleName}: ${e.message}")
            }
            h.postDelayed(this, 700L)
        }
    }

    private val watchdog = object : Runnable {
        override fun run() {
            try { runWatchdog() } catch (e: Exception) {
                Prefs.setDebug(this@AutoPosterAccessibilityService, "Watchdog: ${e.javaClass.simpleName}: ${e.message}")
            }
            h.postDelayed(this, 2200L)
        }
    }

    private val chatPoll = object : Runnable {
        override fun run() {
            syncRunState()
            if (Prefs.getStage(this@AutoPosterAccessibilityService) == Prefs.STAGE_CHATGPT) {
                handleChatGpt(fromPoll = true)
            }
            h.postDelayed(this, 800L)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        recoveryEngine = RecoveryEngine(this)
        h.removeCallbacks(chatPoll)
        h.removeCallbacks(platformPoll)
        h.removeCallbacks(watchdog)
        h.postDelayed(chatPoll, 400L)
        h.postDelayed(platformPoll, 700L)
        h.postDelayed(watchdog, 1800L)
        EventLog.add(this, "SERVICE", "Accessibility verbunden")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        syncRunState()
        val pkg = event?.packageName?.toString().orEmpty()
        if (pkg in setOf(PackageTargets.CHATGPT, PackageTargets.TIKTOK, PackageTargets.FACEBOOK, PackageTargets.YOUTUBE)) {
            Prefs.setLastPackage(this, pkg)
        }

        when (Prefs.getStage(this)) {
            Prefs.STAGE_CHATGPT -> {
                if (pkg == PackageTargets.CHATGPT) handleChatGpt(fromPoll = false)
            }
            Prefs.STAGE_WAIT_MEDIA -> handleWaitMedia(pkg)
            Prefs.STAGE_TIKTOK -> if (pkg == PackageTargets.TIKTOK) {
                handlePlatform(Prefs.STAGE_TIKTOK, Prefs.metadata(this).tiktokText(), listOf("Posten", "Post"))
            }
            Prefs.STAGE_FACEBOOK -> if (pkg == PackageTargets.FACEBOOK) {
                handlePlatform(Prefs.STAGE_FACEBOOK, Prefs.metadata(this).facebookText(), listOf("Posten", "Post", "Veröffentlichen", "Publish"))
            }
            Prefs.STAGE_YOUTUBE -> if (pkg == PackageTargets.YOUTUBE) handleYouTube()
            Prefs.STAGE_AI_REPAIR -> if (pkg == PackageTargets.CHATGPT) handleAiRepair()
        }
    }

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        h.removeCallbacks(chatPoll)
        h.removeCallbacks(platformPoll)
        h.removeCallbacks(watchdog)
        super.onDestroy()
    }

    private fun syncRunState() {
        val run = Prefs.getRunId(this)
        if (run == observedRunId) return
        observedRunId = run
        captureInFlight = false
        fallbackImageOpened = false
        fallbackSaveRequested = false
        downloadPollStarted = false
        platformCaptionFilled = false
        platformFinalClicked = false
        metadataScrollAttempts = 0
        imageScrollAttempts = 0
        captureFailures = 0
        lastActionAt = 0L
        lastRecoveryAt = 0L
        aiRequestSent = false
        aiSendClicked = false
        aiScreenshot = null
        sourceNavState = 0
        sourceNavLastAt = 0L
        saveRequestedAt = 0L
        tiktokEnteredAt = 0L
        tiktokAdvanceCount = 0
        tiktokLastAdvanceAt = 0L
        tiktokStableFp = ""
        tiktokStableSince = 0L
        Prefs.setDebug(this, "Neuer Lauf #$run erkannt")
    }

    /**
     * rootInActiveWindow can briefly point to MIUI launcher/overlays even when the
     * triggering event came from ChatGPT. Always select a window whose root really
     * belongs to the requested package.
     */
    private fun rootForPackage(pkg: String): AccessibilityNodeInfo? {
        try {
            windows.asReversed().forEach { w ->
                val r = w.root ?: return@forEach
                if (r.packageName?.toString() == pkg) return r
            }
        } catch (_: Exception) { }
        return rootInActiveWindow?.takeIf { it.packageName?.toString() == pkg }
    }

    private fun handleChatGpt(fromPoll: Boolean) {
        if (!ready(if (fromPoll) 500L else 250L)) return

        val root = rootForPackage(PackageTargets.CHATGPT)
        if (root == null) {
            Prefs.setStatus(this, "Warte auf ChatGPT-Fenster …")
            Prefs.setDebug(this, "Kein ChatGPT-Root gefunden; aktiver Root=${rootInActiveWindow?.packageName ?: "–"}")
            return
        }

        Prefs.setLastPackage(this, PackageTargets.CHATGPT)
        val all = collectText(root)

        if (!Prefs.hasMetadata(this)) {
            MetadataParser.parse(all)?.let {
                Prefs.saveMetadata(this, it)
                Prefs.setStatus(this, "AUTOPOST-Daten erkannt. Suche Bild …")
                Prefs.setDebug(this, "Metadaten erkannt; ChatGPT-Root bestätigt")
                toastOnce("AutoPoster: Text erkannt")
            }
        }

        if (!Prefs.hasMetadata(this)) {
            Prefs.setStatus(this, "ChatGPT: suche neuesten AutoPoster-Post …")
            Prefs.setDebug(this, "AUTOPOST noch nicht sichtbar; Quellchat=${Prefs.sourceChatName(this)}; Text=${all.take(180)}")

            // Give the currently open conversation two quick scroll attempts. If it
            // is not our source chat, navigate to the one fixed chat title instead
            // of asking the user to open it manually every run.
            if (metadataScrollAttempts < 2 && scrollAny(root, forward = false)) {
                metadataScrollAttempts++
                return
            }
            if (navigateToSourceChat(root)) return
            if (metadataScrollAttempts < 8 && scrollAny(root, forward = false)) {
                metadataScrollAttempts++
                return
            }
            if (metadataScrollAttempts < 12 && scrollAny(root, forward = true)) {
                metadataScrollAttempts++
                return
            }
            return
        }

        // V2.1: once the ORIGINAL image viewer is open, only use an explicit
        // Download/Save action. A screen capture is NEVER accepted as post media.
        if (fallbackImageOpened) {
            if (!fallbackSaveRequested) {
                if (clickByLabels(root, listOf("Herunterladen", "Download", "Download image", "Bild herunterladen", "Speichern", "Save image", "Bild speichern"))) {
                    fallbackSaveRequested = true
                    saveRequestedAt = System.currentTimeMillis()
                    Prefs.setStage(this, Prefs.STAGE_WAIT_MEDIA)
                    Prefs.setStatus(this, "Originalbild wird gespeichert …")
                    Prefs.setDebug(this, "Original-Download im ChatGPT-Bildviewer ausgelöst")
                    startDownloadPoll()
                } else {
                    Prefs.setStatus(this, "Bild geöffnet – suche Download/Speichern …")
                }
            }
            return
        }

        // V1.3: ChatGPT's generated image is not always exposed as an ImageView in
        // the Android accessibility tree (Compose can expose only text). First try
        // normal and generic portrait nodes. If that still fails, use the visible
        // [AUTOPOST_V1] marker as an anchor and detect the 9:16 image directly in a
        // full-screen screenshot. This avoids the generic ChatGPT Share button.
        if (!captureInFlight) {
            val marker = findNodeContaining(root, "[AUTOPOST_V1]")
                ?: findNodeContaining(root, "[TIKTOK_TITLE]")
                ?: Prefs.metadata(this).tiktokTitle.take(28).takeIf { it.isNotBlank() }?.let { findNodeContaining(root, it) }
            val markerRect = marker?.let { Rect().also { r -> it.getBoundsInScreen(r) } }?.takeIf { it.width() > 20 && it.top > 100 }
            val image = largestImageLikeNode(root)
                ?: largestPortraitNode(root, markerRect?.top ?: Int.MAX_VALUE)

            if (image != null && clickNodeOrParent(image)) {
                fallbackImageOpened = true
                Prefs.setStatus(this, "Originalbild geöffnet – suche Download …")
                Prefs.setDebug(this, "Bild über Accessibility geöffnet; kein Screenshot als Medium")
                return
            }

            // ChatGPT/Compose often hides the image from Accessibility. In that case
            // take a screenshot ONLY to find the visual rectangle, then TAP the real
            // ChatGPT image. Never crop/save the screenshot as social media media.
            if (captureFailures < 3 && markerRect != null) {
                locateAndOpenOriginalImage(markerRect)
                return
            }

            if (imageScrollAttempts < 10 && scrollAny(root, forward = false)) {
                imageScrollAttempts++
                Prefs.setStatus(this, "Text erkannt – scrolle zum Bild …")
                Prefs.setDebug(this, "Metadaten da; Bild/Marker noch nicht lokalisierbar; Versuch $imageScrollAttempts")
                return
            }
        }

        // No generic ChatGPT share fallback here. Screenshot data is diagnostic
        // only; AutoPoster must obtain the original downloaded image before posting.
    }

    private fun locateAndOpenOriginalImage(markerBounds: Rect) {
        if (captureInFlight) return
        captureInFlight = true
        Prefs.setStatus(this, "Lokalisiere Originalbild …")
        Prefs.setDebug(this, "Screenshot nur zur Koordinatenerkennung; marker=$markerBounds")

        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(result: ScreenshotResult) {
                try {
                    val buffer = result.hardwareBuffer
                    val hw = Bitmap.wrapHardwareBuffer(buffer, result.colorSpace)
                    val full = hw?.copy(Bitmap.Config.ARGB_8888, false)
                    buffer.close()
                    if (full == null) throw IllegalStateException("Screenshot-Bitmap leer")
                    val chosen = detectImageRect(full, markerBounds)
                        ?: throw IllegalStateException("Kein plausibler Bildbereich erkannt")
                    val x = chosen.centerX().toFloat()
                    val y = chosen.centerY().toFloat()
                    full.recycle()
                    captureInFlight = false
                    if (!tapScreen(x, y)) throw IllegalStateException("Bild-Tap konnte nicht gesendet werden")
                    fallbackImageOpened = true
                    Prefs.setStatus(this@AutoPosterAccessibilityService, "Originalbild geöffnet – warte auf Download …")
                    Prefs.setDebug(this@AutoPosterAccessibilityService, "Bild nur lokalisiert und an $x/$y geöffnet; Screenshot verworfen")
                    Prefs.markProgress(this@AutoPosterAccessibilityService, "chatgpt-original-image-opened")
                } catch (e: Exception) {
                    captureInFlight = false
                    captureFailures++
                    Prefs.setStatus(this@AutoPosterAccessibilityService, "Originalbild-Lokalisierung ${captureFailures}/3 fehlgeschlagen")
                    Prefs.setDebug(this@AutoPosterAccessibilityService, "Bild-Locator #$captureFailures: ${e.javaClass.simpleName}: ${e.message}")
                    EventLog.add(this@AutoPosterAccessibilityService, "FAIL", "Bild-Locator #$captureFailures: ${e.message}")
                }
            }

            override fun onFailure(errorCode: Int) {
                captureInFlight = false
                captureFailures++
                Prefs.setStatus(this@AutoPosterAccessibilityService, "Bild-Lokalisierung nicht möglich – Recovery übernimmt")
                Prefs.setDebug(this@AutoPosterAccessibilityService, "Locator-Screenshot Fehlercode=$errorCode")
            }
        })
    }

    private fun tapScreen(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, 80L))
            .build()
        return dispatchGesture(gesture, null, null)
    }

    private fun clampRect(src: Rect, width: Int, height: Int): Rect? {
        if (width < 2 || height < 2) return null
        val left = src.left.coerceIn(0, width - 1)
        val top = src.top.coerceIn(0, height - 1)
        val right = src.right.coerceIn(left + 1, width)
        val bottom = src.bottom.coerceIn(top + 1, height)
        return Rect(left, top, right, bottom)
    }

    /**
     * Pixel fallback for ChatGPT Compose UI. The [AUTOPOST_V1] marker is directly
     * below the generated image in our task output. We search the area above that
     * marker for the nearest tall, dense non-background region and normalize it to
     * a 9:16 crop. Works in both dark and light ChatGPT themes.
     */
    private fun detectImageRect(bitmap: Bitmap, marker: Rect?): Rect? {
        if (marker == null) return null
        val w = bitmap.width
        val h = bitmap.height
        if (w < 240 || h < 400) return null

        val markerTop = marker.top.coerceIn((h * 0.20f).toInt(), h - 1)
        val roiBottom = (markerTop - (h * 0.008f).toInt()).coerceAtLeast(1)
        val roiTop = (roiBottom - (h * 0.72f).toInt()).coerceAtLeast((h * 0.05f).toInt())
        if (roiBottom - roiTop < 180) return null

        // Estimate ChatGPT page background from the far right edge. Median makes
        // this resilient to occasional icons/text crossing one sample point.
        val rs = mutableListOf<Int>(); val gs = mutableListOf<Int>(); val bs = mutableListOf<Int>()
        val sx = (w - 4).coerceAtLeast(0)
        var sy = roiTop
        val sampleStep = ((roiBottom - roiTop) / 16).coerceAtLeast(1)
        while (sy < roiBottom) {
            val c = bitmap.getPixel(sx, sy)
            rs += android.graphics.Color.red(c)
            gs += android.graphics.Color.green(c)
            bs += android.graphics.Color.blue(c)
            sy += sampleStep
        }
        fun median(v: MutableList<Int>): Int { v.sort(); return v[v.size / 2] }
        val br = median(rs); val bg = median(gs); val bb = median(bs)

        fun different(c: Int): Boolean {
            val d = kotlin.math.abs(android.graphics.Color.red(c) - br) +
                kotlin.math.abs(android.graphics.Color.green(c) - bg) +
                kotlin.math.abs(android.graphics.Color.blue(c) - bb)
            return d > 72
        }

        // Find dense row segments. Text rows are sparse; the generated image is dense.
        val rowStepX = 4
        val activeRows = BooleanArray(roiBottom - roiTop)
        for (yy in roiTop until roiBottom) {
            var diff = 0; var total = 0
            var xx = 0
            while (xx < w) {
                if (different(bitmap.getPixel(xx, yy))) diff++
                total++
                xx += rowStepX
            }
            activeRows[yy - roiTop] = total > 0 && diff.toFloat() / total >= 0.16f
        }

        data class Seg(val a: Int, val b: Int) { val len get() = b - a }
        val rows = mutableListOf<Seg>()
        var i = 0
        while (i < activeRows.size) {
            if (!activeRows[i]) { i++; continue }
            val a = i
            while (i < activeRows.size && activeRows[i]) i++
            val b = i
            if (b - a >= (w * 0.38f).toInt()) rows += Seg(roiTop + a, roiTop + b)
        }
        val row = rows.minByOrNull { kotlin.math.abs(roiBottom - it.b) } ?: return markerAspectFallback(bitmap, marker)

        // Determine horizontal image bounds across the detected image-height segment.
        val y1 = row.a.coerceAtLeast(0)
        val y2 = row.b.coerceAtMost(h)
        val activeCols = BooleanArray(w)
        val rowStepY = 5
        for (xx in 0 until w) {
            var diff = 0; var total = 0
            var yy = y1
            while (yy < y2) {
                if (different(bitmap.getPixel(xx, yy))) diff++
                total++
                yy += rowStepY
            }
            activeCols[xx] = total > 0 && diff.toFloat() / total >= 0.24f
        }
        val cols = mutableListOf<Seg>()
        i = 0
        while (i < activeCols.size) {
            if (!activeCols[i]) { i++; continue }
            val a = i
            while (i < activeCols.size && activeCols[i]) i++
            val b = i
            if (b - a >= (w * 0.24f).toInt()) cols += Seg(a, b)
        }
        val col = cols.maxByOrNull { it.len } ?: return markerAspectFallback(bitmap, marker)

        var left = (col.a - 3).coerceAtLeast(0)
        var right = (col.b + 3).coerceAtMost(w)
        var width = right - left
        if (width < (w * 0.24f).toInt()) return markerAspectFallback(bitmap, marker)

        // Normalize to the expected 9:16 image ratio. Align its bottom immediately
        // above the metadata marker; this restores dark/faded image edges that a pure
        // pixel detector can miss.
        val expectedHeight = (width * 16f / 9f).toInt()
        val gap = (h * 0.010f).toInt().coerceAtLeast(6)
        var bottom = (markerTop - gap).coerceAtMost(h)
        var top = bottom - expectedHeight
        if (top < 0) {
            top = 0
            val adjustedWidth = ((bottom - top) * 9f / 16f).toInt()
            right = (left + adjustedWidth).coerceAtMost(w)
            width = right - left
        }
        if (width <= 0 || bottom - top <= 0) return null
        return Rect(left, top, right, bottom)
    }

    private fun markerAspectFallback(bitmap: Bitmap, marker: Rect): Rect? {
        val w = bitmap.width; val h = bitmap.height
        val markerTop = marker.top.coerceIn(1, h)
        val left = marker.left.coerceIn(0, w - 2)
        var width = (w * 0.54f).toInt().coerceAtMost(w - left)
        var height = (width * 16f / 9f).toInt()
        val gap = (h * 0.010f).toInt().coerceAtLeast(6)
        val bottom = (markerTop - gap).coerceAtLeast(1)
        if (height > bottom) {
            height = bottom
            width = (height * 9f / 16f).toInt()
        }
        if (width < 120 || height < 160) return null
        return Rect(left, bottom - height, (left + width).coerceAtMost(w), bottom)
    }

    private fun handleWaitMedia(pkg: String) {
        if (fallbackSaveRequested && !downloadPollStarted) startDownloadPoll()
        if (pkg == PackageTargets.CHATGPT && !fallbackSaveRequested) {
            Prefs.setStage(this, Prefs.STAGE_CHATGPT)
            return
        }
    }

    private fun startDownloadPoll() {
        if (downloadPollStarted) return
        downloadPollStarted = true
        val started = saveRequestedAt.takeIf { it > 0L } ?: System.currentTimeMillis()
        var tries = 0
        fun poll() {
            if (Prefs.getStage(this) != Prefs.STAGE_WAIT_MEDIA) return
            tries++
            val media = try { MediaStoreHelper.latestRealImageAfter(this, started) } catch (_: SecurityException) { null }
            if (media != null) {
                val path = MediaStoreHelper.copyToCache(this, media.uri, media.mime)
                if (!path.isNullOrBlank()) {
                    Prefs.setMedia(this, path, media.mime)
                    Prefs.setStatus(this, "Originalbild übernommen. Starte Plattformen …")
                    Prefs.setDebug(this, "Original aus MediaStore: ${media.name} / ${media.relativePath}")
                    PostingOrchestrator.afterMediaCaptured(this)
                    return
                }
            }
            if (tries < 24) {
                h.postDelayed({ poll() }, 750)
            } else {
                downloadPollStarted = false
                fallbackSaveRequested = false
                Prefs.setStage(this, Prefs.STAGE_CHATGPT)
                Prefs.setStatus(this, "Speichern nicht erkannt")
                Prefs.setDebug(this, "Kein neues Bild nach explizitem Save gefunden")
            }
        }
        h.postDelayed({ poll() }, 700)
    }

    private fun handlePlatform(stage: String, text: String, finalLabels: List<String>) {
        if (!ready(450)) return
        val pkg = when (stage) {
            Prefs.STAGE_TIKTOK -> PackageTargets.TIKTOK
            Prefs.STAGE_FACEBOOK -> PackageTargets.FACEBOOK
            else -> return
        }
        val root = rootForPackage(pkg) ?: return

        if (stage == Prefs.STAGE_TIKTOK) {
            handleTikTok(root, text, finalLabels)
            return
        }

        if (!platformCaptionFilled) {
            val editable = findBestEditable(root)
            if (editable != null && text.isNotBlank()) {
                if (setText(editable, text)) {
                    platformCaptionFilled = true
                    Prefs.markProgress(this, "$stage-caption")
                    Prefs.setStatus(this, "$stage: Text eingefügt")
                    return
                }
            }
            if (clickByLabels(root, listOf("Weiter", "Next", "Fertig", "Done"))) return
        }

        if (platformCaptionFilled && !platformFinalClicked) {
            if (Prefs.isTestMode(this)) {
                Prefs.setStatus(this, "$stage Testmodus: vor dem finalen Post gestoppt")
                toastOnce("AutoPoster Testmodus: vor Post gestoppt")
                return
            }
            if (clickByLabels(root, finalLabels)) {
                platformFinalClicked = true
                Prefs.setStatus(this, "$stage: Veröffentlichung ausgelöst")
                PostingOrchestrator.finishPlatform(this, stage)
                resetPlatformFlagsLater()
            }
        }
    }

    private fun handleTikTok(root: AccessibilityNodeInfo, text: String, finalLabels: List<String>) {
        val now = System.currentTimeMillis()
        if (tiktokEnteredAt == 0L) {
            tiktokEnteredAt = now
            Prefs.markProgress(this, "tiktok-editor-entered")
        }

        // The publish/preview screen has an editable caption/title field. As soon
        // as that is visible, stop advancing and fill it.
        val editable = findBestEditable(root)
        if (!platformCaptionFilled && editable != null && text.isNotBlank()) {
            if (setText(editable, text)) {
                platformCaptionFilled = true
                Prefs.markProgress(this, "TIKTOK-caption")
                Prefs.setStatus(this, "TikTok: Text eingefügt – bereit zur Kontrolle")
                return
            }
        }

        if (!platformCaptionFilled) {
            // TikTok often selects/loads a recommended sound asynchronously after
            // receiving the photo. Never race directly to the publish screen.
            val minWait = 10_000L
            val elapsed = now - tiktokEnteredAt
            if (elapsed < minWait) {
                val left = ((minWait - elapsed + 999L) / 1000L).coerceAtLeast(1L)
                Prefs.setStatus(this, "TikTok: warte auf automatische Musik … ${left}s")
                return
            }

            // Also require the editor accessibility tree to stay stable briefly.
            val fp = fingerprint(PackageTargets.TIKTOK, "EDITOR", collectText(root))
            if (fp != tiktokStableFp) {
                tiktokStableFp = fp
                tiktokStableSince = now
                Prefs.setStatus(this, "TikTok: Musik/Editor stabilisiert sich …")
                return
            }
            if (now - tiktokStableSince < 1_500L) return
            if (now - tiktokLastAdvanceAt < 2_500L) return

            // Some TikTok versions have one editor step, others two. Advance at
            // most twice, and only after the sound wait/stability gate.
            if (tiktokAdvanceCount < 2 && clickByLabels(root, listOf("Weiter", "Next", "Fertig", "Done"))) {
                tiktokAdvanceCount++
                tiktokLastAdvanceAt = now
                tiktokStableFp = ""
                tiktokStableSince = 0L
                Prefs.markProgress(this, "tiktok-next-$tiktokAdvanceCount")
                Prefs.setStatus(this, "TikTok: Weiter nach Musik-Wartezeit")
            }
            return
        }

        if (!platformFinalClicked) {
            if (Prefs.isTestMode(this)) {
                Prefs.setStatus(this, "TikTok Testmodus: vor Veröffentlichen gestoppt")
                toastOnce("AutoPoster Testmodus: vor TikTok-Post gestoppt")
                return
            }
            if (clickByLabels(root, finalLabels)) {
                platformFinalClicked = true
                Prefs.setStatus(this, "TikTok: Veröffentlichung ausgelöst")
                PostingOrchestrator.finishPlatform(this, Prefs.STAGE_TIKTOK)
                resetPlatformFlagsLater()
            }
        }
    }

    private fun handleYouTube() {
        if (!ready(550)) return
        val root = rootForPackage(PackageTargets.YOUTUBE) ?: return
        val text = Prefs.metadata(this).youtubeText()
        if (!platformCaptionFilled) {
            val editable = findBestEditable(root)
            if (editable != null && text.isNotBlank() && setText(editable, text)) {
                platformCaptionFilled = true
                Prefs.markProgress(this, "YOUTUBE-caption")
                Prefs.setStatus(this, "YouTube: Short-Titel/Text eingefügt")
                return
            }
            clickByLabels(root, listOf("Weiter", "Next", "Short erstellen", "Create a Short", "Kurzvideo erstellen"))
            return
        }
        if (Prefs.isTestMode(this)) {
            Prefs.setStatus(this, "YouTube Testmodus: vor Upload gestoppt")
            return
        }
        if (!platformFinalClicked && clickByLabels(root, listOf("Short hochladen", "Upload Short", "Hochladen", "Upload", "Posten", "Post"))) {
            platformFinalClicked = true
            Prefs.setStatus(this, "YouTube: Upload ausgelöst")
            PostingOrchestrator.finishPlatform(this, Prefs.STAGE_YOUTUBE)
            resetPlatformFlagsLater()
        }
    }

    private fun resetPlatformFlagsLater() {
        h.postDelayed({
            platformCaptionFilled = false
            platformFinalClicked = false
        }, 3500)
    }

    private fun runWatchdog() {
        syncRunState()
        if (!Prefs.isAutoRecovery(this)) return
        val stage = Prefs.getStage(this)
        if (stage in setOf(Prefs.STAGE_IDLE, Prefs.STAGE_DONE, Prefs.STAGE_AI_REPAIR)) return
        val now = System.currentTimeMillis()
        val last = Prefs.lastProgressAt(this)
        if (last <= 0L || now - last < 12_000L || now - lastRecoveryAt < 5_000L) return
        lastRecoveryAt = now
        val round = Prefs.incRecoveryRound(this)
        EventLog.add(this, "RECOVERY", "Runde $round in $stage")
        performRecovery(stage, round)
    }

    private fun performRecovery(stage: String, round: Int) {
        val pkg = when (stage) {
            Prefs.STAGE_CHATGPT, Prefs.STAGE_WAIT_MEDIA -> PackageTargets.CHATGPT
            Prefs.STAGE_TIKTOK -> PackageTargets.TIKTOK
            Prefs.STAGE_FACEBOOK -> PackageTargets.FACEBOOK
            Prefs.STAGE_YOUTUBE -> PackageTargets.YOUTUBE
            else -> ""
        }
        val root = if (pkg.isNotBlank()) rootForPackage(pkg) else null
        val text = root?.let { collectText(it) }.orEmpty()
        val fp = fingerprint(pkg, stage, text)
        Prefs.setScreenFingerprint(this, fp)
        val snap = RecoveryEngine.ContextSnapshot(stage, pkg, text, fp)
        val order = recoveryEngine.chooseOrder(this, snap)

        var used: String? = null
        for (strategy in order) {
            val ok = when (strategy) {
                "chat-scroll-up" -> recoveryEngine.scroll(root, forward = false)
                "chat-scroll-down" -> recoveryEngine.scroll(root, forward = true)
                "chat-reopen" -> recoveryEngine.reopen(PackageTargets.CHATGPT)
                "platform-next" -> {
                    if (stage == Prefs.STAGE_TIKTOK && tiktokEnteredAt > 0L && System.currentTimeMillis() - tiktokEnteredAt < 10_000L) false
                    else root?.let { clickByLabels(it, listOf("Weiter", "Next", "Fertig", "Done")) } ?: false
                }
                "platform-scroll" -> recoveryEngine.scroll(root, forward = true)
                "platform-reopen" -> recoveryEngine.reopen(pkg)
                "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
                "reopen" -> if (pkg.isNotBlank()) recoveryEngine.reopen(pkg) else false
                else -> false
            }
            if (ok) { used = strategy; break }
        }

        if (used != null) {
            Prefs.setStatus(this, "Recovery $round: $used")
            Prefs.setDebug(this, "Self-Healing: $used auf $stage / $fp")
            EventLog.add(this, "TRY", used)
            // Do not mark success yet. Strategy is remembered only when the stage later progresses.
            h.postDelayed({
                if (Prefs.lastProgressAt(this) > lastRecoveryAt) {
                    StrategyMemory.remember(this, pkg, stage, fp, used!!)
                }
            }, 4500L)
            return
        }

        if (round >= 3 && Prefs.isAiAssist(this)) {
            startAiRepair(stage, fp)
        } else {
            Prefs.setStatus(this, "Recovery $round: kein lokaler Weg – neuer Versuch folgt")
            Prefs.setDebug(this, "Alle lokalen Strategien für $stage ohne Aktion")
        }
    }

    private fun startAiRepair(stage: String, fp: String) {
        if (aiRequestSent) return
        aiRequestSent = true
        Prefs.setStatus(this, "Lokale Recovery erschöpft – ChatGPT Assist …")
        EventLog.add(this, "AI", "ChatGPT Assist für $stage gestartet")
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(result: ScreenshotResult) {
                try {
                    val buffer = result.hardwareBuffer
                    val hw = Bitmap.wrapHardwareBuffer(buffer, result.colorSpace)
                    val full = hw?.copy(Bitmap.Config.ARGB_8888, false)
                    buffer.close()
                    if (full != null) {
                        val f = File(cacheDir, "repair_${Prefs.getRunId(this@AutoPosterAccessibilityService)}.png")
                        FileOutputStream(f).use { full.compress(Bitmap.CompressFormat.PNG, 92, it) }
                        full.recycle(); aiScreenshot = f
                    }
                } catch (_: Exception) { }
                launchAiBridge(stage, fp)
            }
            override fun onFailure(errorCode: Int) { launchAiBridge(stage, fp) }
        })
    }

    private fun launchAiBridge(stage: String, fp: String) {
        val ok = ChatGptRepairBridge.launch(this, aiScreenshot, stage, fp, Prefs.debug(this))
        if (ok) {
            Prefs.setStage(this, Prefs.STAGE_AI_REPAIR)
            Prefs.setStatus(this, "ChatGPT Assist geöffnet – warte auf Reparaturplan …")
        } else {
            aiRequestSent = false
            Prefs.setStatus(this, "ChatGPT Assist konnte nicht geöffnet werden")
        }
    }

    private fun handleAiRepair() {
        if (!ready(700)) return
        val root = rootForPackage(PackageTargets.CHATGPT) ?: return
        val all = collectText(root)
        val commands = SafeAutofix.parse(all)
        if (commands.isNotEmpty()) {
            EventLog.add(this, "AI", "${commands.size} sichere Befehle empfangen")
            val originalStage = inferOriginalStageFromLog()
            executeSafeCommands(commands, originalStage)
            return
        }
        if (!aiSendClicked) {
            val editable = findBestEditable(root)
            // ACTION_SEND usually prefills the composer. Only click the send control; never tap generic Share.
            if (editable != null && clickByLabels(root, listOf("Senden", "Send", "Nachricht senden"))) {
                aiSendClicked = true
                Prefs.setStatus(this, "ChatGPT Assist: Reparaturanfrage gesendet")
                return
            }
        }
        scrollAny(root, forward = true)
    }

    private fun inferOriginalStageFromLog(): String {
        val log = EventLog.text(this)
        return when {
            log.contains(" in TIKTOK") -> Prefs.STAGE_TIKTOK
            log.contains(" in FACEBOOK") -> Prefs.STAGE_FACEBOOK
            log.contains(" in YOUTUBE") -> Prefs.STAGE_YOUTUBE
            else -> Prefs.STAGE_CHATGPT
        }
    }

    private fun executeSafeCommands(commands: List<SafeAutofix.Command>, returnStage: String) {
        val targetPkg = when (returnStage) {
            Prefs.STAGE_TIKTOK -> PackageTargets.TIKTOK
            Prefs.STAGE_FACEBOOK -> PackageTargets.FACEBOOK
            Prefs.STAGE_YOUTUBE -> PackageTargets.YOUTUBE
            else -> PackageTargets.CHATGPT
        }
        recoveryEngine.reopen(targetPkg)
        var delay = 1200L
        commands.forEach { cmd ->
            h.postDelayed({
                when (cmd) {
                    SafeAutofix.Command.ScrollUp -> rootInActiveWindow?.let { recoveryEngine.scroll(it, false) }
                    SafeAutofix.Command.ScrollDown -> rootInActiveWindow?.let { recoveryEngine.scroll(it, true) }
                    SafeAutofix.Command.Back -> performGlobalAction(GLOBAL_ACTION_BACK)
                    is SafeAutofix.Command.Wait -> Unit
                    is SafeAutofix.Command.TapText -> rootInActiveWindow?.let { clickByLabels(it, listOf(cmd.text)) }
                    is SafeAutofix.Command.Reopen -> {
                        val pkg = when (cmd.target) {
                            "chatgpt" -> PackageTargets.CHATGPT
                            "tiktok" -> PackageTargets.TIKTOK
                            "facebook" -> PackageTargets.FACEBOOK
                            "youtube" -> PackageTargets.YOUTUBE
                            else -> ""
                        }
                        if (pkg.isNotBlank()) recoveryEngine.reopen(pkg)
                    }
                }
            }, delay)
            delay += if (cmd is SafeAutofix.Command.Wait) cmd.seconds * 1000L else 900L
        }
        h.postDelayed({
            aiRequestSent = false; aiSendClicked = false
            Prefs.setStage(this, returnStage)
            Prefs.markProgress(this, "ai-repair-plan-executed")
            Prefs.setStatus(this, "ChatGPT-Reparaturplan ausgeführt – normaler Ablauf läuft weiter")
        }, delay + 800L)
    }

    private fun fingerprint(pkg: String, stage: String, text: String): String {
        val normalized = text.lowercase().replace(Regex("\\d+"), "#").replace(Regex("\\s+"), " ").take(500)
        val bytes = MessageDigest.getInstance("SHA-256").digest("$pkg|$stage|$normalized".toByteArray())
        return bytes.take(6).joinToString("") { "%02x".format(it) }
    }

    private fun ready(ms: Long = 350): Boolean {
        val n = System.currentTimeMillis()
        if (n - lastActionAt < ms) return false
        lastActionAt = n
        return true
    }

    /** Navigate to one fixed ChatGPT conversation. The user only has to rename
     * that source chat once (default: AUTOPOSTER QUELLE). */
    private fun navigateToSourceChat(root: AccessibilityNodeInfo): Boolean {
        val now = System.currentTimeMillis()
        if (now - sourceNavLastAt < 650L) return false
        val target = Prefs.sourceChatName(this)
        if (target.isBlank()) return false

        // If the target title is visible in sidebar/search results, open it.
        findExactNode(root, target)?.let { node ->
            if (clickNodeOrParent(node)) {
                sourceNavState = 4
                sourceNavLastAt = now
                metadataScrollAttempts = 0
                Prefs.setStatus(this, "ChatGPT: Quellchat '$target' geöffnet …")
                Prefs.markProgress(this, "source-chat-opened")
                return true
            }
        }

        when (sourceNavState) {
            0 -> {
                if (clickByLabels(root, listOf("Open sidebar", "Seitenleiste öffnen", "Sidebar öffnen", "Chats öffnen", "Open chats"))) {
                    sourceNavState = 1; sourceNavLastAt = now
                    Prefs.setStatus(this, "ChatGPT: öffne Chat-Liste …")
                    return true
                }
                // Search may already be directly available in the current layout.
                if (clickByLabels(root, listOf("Search", "Suchen", "Chats durchsuchen", "Search chats"))) {
                    sourceNavState = 2; sourceNavLastAt = now
                    return true
                }
            }
            1 -> {
                if (clickByLabels(root, listOf("Search", "Suchen", "Chats durchsuchen", "Search chats"))) {
                    sourceNavState = 2; sourceNavLastAt = now
                    Prefs.setStatus(this, "ChatGPT: suche Quellchat …")
                    return true
                }
            }
            2 -> {
                val edit = findBestEditable(root)
                if (edit != null && setText(edit, target)) {
                    sourceNavState = 3; sourceNavLastAt = now
                    Prefs.setStatus(this, "ChatGPT: suche '$target' …")
                    return true
                }
            }
            3 -> {
                // Waiting for search results; the exact-title branch above opens it.
                sourceNavLastAt = now
                return false
            }
        }
        return false
    }

    private fun findExactNode(root: AccessibilityNodeInfo, value: String): AccessibilityNodeInfo? {
        var found: AccessibilityNodeInfo? = null
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || found != null) return
            val t = n.text?.toString()?.trim().orEmpty()
            val d = n.contentDescription?.toString()?.trim().orEmpty()
            if (t.equals(value, true) || d.equals(value, true)) { found = n; return }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return found
    }

    private fun collectText(root: AccessibilityNodeInfo): String {
        val sb = StringBuilder()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            n.text?.toString()?.takeIf { it.isNotBlank() }?.let { sb.append(it).append('\n') }
            n.contentDescription?.toString()?.takeIf { it.isNotBlank() }?.let { sb.append(it).append('\n') }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return sb.toString()
    }

    private fun findNodeContaining(root: AccessibilityNodeInfo, token: String): AccessibilityNodeInfo? {
        var found: AccessibilityNodeInfo? = null
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || found != null) return
            val value = n.text?.toString().orEmpty() + " " + n.contentDescription?.toString().orEmpty()
            if (value.contains(token, ignoreCase = true)) {
                found = n
                return
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return found
    }

    /** Catch Compose/generic View containers that visually are a portrait image even
     * when neither className nor contentDescription says "image". */
    private fun largestPortraitNode(root: AccessibilityNodeInfo, markerTop: Int): AccessibilityNodeInfo? {
        var best: AccessibilityNodeInfo? = null
        var bestArea = 0L
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            val r = Rect(); n.getBoundsInScreen(r)
            val ww = r.width(); val hh = r.height()
            if (ww > 120 && hh > 180 && !n.isScrollable && r.top >= 0 && r.bottom <= markerTop + 60) {
                val ratio = hh.toFloat() / ww.toFloat()
                val area = ww.toLong() * hh.toLong()
                if (ratio in 1.35f..2.10f && area > bestArea) {
                    bestArea = area
                    best = n
                }
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return best
    }

    private fun largestImageLikeNode(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var best: AccessibilityNodeInfo? = null
        var area = 0L
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            val cls = n.className?.toString().orEmpty()
            val desc = n.contentDescription?.toString().orEmpty().lowercase()
            val text = n.text?.toString().orEmpty().lowercase()
            val likely = cls.contains("ImageView") || desc.contains("image") || desc.contains("bild") || desc.contains("generated") || text == "image" || text == "bild"
            if (likely) {
                val r = Rect()
                n.getBoundsInScreen(r)
                val a = r.width().toLong() * r.height().toLong()
                if (a > area && a > 40_000) {
                    area = a
                    best = n
                }
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return best
    }

    private fun findBestEditable(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val found = mutableListOf<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            val cls = n.className?.toString().orEmpty()
            if (n.isEditable || cls.contains("EditText")) found += n
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return found.maxByOrNull {
            val r = Rect()
            it.getBoundsInScreen(r)
            r.width().toLong() * r.height().toLong()
        }
    }

    private fun setText(n: AccessibilityNodeInfo, value: String): Boolean {
        val b = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, value)
        }
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    private fun scrollAny(root: AccessibilityNodeInfo, forward: Boolean): Boolean {
        val action = if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        val nodes = mutableListOf<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            if (n.isScrollable) nodes += n
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return nodes.asReversed().any { it.performAction(action) }
    }

    private fun clickByLabels(root: AccessibilityNodeInfo, labels: List<String>): Boolean {
        val candidates = mutableListOf<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            val t = (n.text?.toString().orEmpty() + " " + n.contentDescription?.toString().orEmpty()).trim()
            if (labels.any { label -> t.equals(label, true) || t.contains(label, true) }) candidates += n
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return candidates.asReversed().any { clickNodeOrParent(it) }
    }

    private fun clickNodeOrParent(node: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = node
        repeat(6) {
            if (n?.isClickable == true && n?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true) return true
            n = n?.parent
        }
        return false
    }

    private fun toastOnce(msg: String) {
        val now = System.currentTimeMillis()
        if (msg == lastToast && now - lastToastAt < 8_000L) return
        lastToast = msg
        lastToastAt = now
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
