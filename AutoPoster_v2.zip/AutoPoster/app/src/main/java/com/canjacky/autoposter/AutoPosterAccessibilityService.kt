package com.canjacky.autoposter

import android.accessibilityservice.AccessibilityService
import android.graphics.Bitmap
import android.graphics.Rect
import android.graphics.Path
import android.accessibilityservice.GestureDescription
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import java.security.MessageDigest
import java.io.File
import java.io.FileOutputStream

class AutoPosterAccessibilityService : AccessibilityService() {
    private val h = Handler(Looper.getMainLooper())
    private var lastActionAt = 0L
    private var observedRunId = -1L
    private var captureInFlight = false
    private var fallbackImageOpened = false
    private var fallbackSaveRequested = false
    private var downloadPollStarted = false
    private var platformCaptionFilled = false
    private var platformFinalClicked = false
    private var metadataScrollAttempts = 0
    private var imageScrollAttempts = 0
    private var captureFailures = 0
    private var lastToast = ""
    private var lastToastAt = 0L
    private lateinit var recoveryEngine: RecoveryEngine
    private var lastRecoveryAt = 0L
    private var aiRequestSent = false
    private var aiSendClicked = false
    private var aiScreenshot: File? = null

    // V2.2 source-chat navigation, verified image acquisition and TikTok pacing.
    private var sourceNavState = 0
    private var sourceNavLastAt = 0L
    private var saveRequestedAt = 0L
    private var tiktokEnteredAt = 0L
    private var tiktokAdvanceCount = 0
    private var tiktokLastAdvanceAt = 0L
    private var tiktokStableFp = ""
    private var tiktokStableSince = 0L

    // V2.2: never assume that a tap opened the generated image. Verify the
    // viewer first and handle the Android share chooser only after that.
    private var imageTapPending = false
    private var imageTapAt = 0L
    private var imageViewerEnteredAt = 0L
    private var imageSharePending = false
    private var sourceTargetIndex = 0
    private var sidebarFallbackTaps = 0

    // V2.3 metadata scanner. ChatGPT virtualizes long answers; the complete
    // [AUTOPOST_V1] block is not guaranteed to exist in one accessibility tree.
    // We therefore go to the newest end once, scan upward once, and prepend the
    // visible chunks into a chronological transcript. No up/down ping-pong.
    private var metadataScanPhase = 0 // 0 = seek newest/bottom, 1 = scan upward
    private var metadataScanText = ""
    private var metadataScanSteps = 0
    private var metadataLastFp = ""
    private var metadataSameFpCount = 0
    private var metadataJumpToBottomTried = false

    private val platformPoll = object : Runnable {
        override fun run() {
            try {
                when (Prefs.getStage(this@AutoPosterAccessibilityService)) {
                    Prefs.STAGE_TIKTOK -> handlePlatform(Prefs.STAGE_TIKTOK, Prefs.metadata(this@AutoPosterAccessibilityService).tiktokText(), listOf("Posten", "Post", "Veröffentlichen", "Publish"))
                    Prefs.STAGE_FACEBOOK -> handlePlatform(Prefs.STAGE_FACEBOOK, Prefs.metadata(this@AutoPosterAccessibilityService).facebookText(), listOf("Posten", "Post", "Veröffentlichen", "Publish"))
                    Prefs.STAGE_YOUTUBE -> handleYouTube()
                }
            } catch (e: Exception) {
                Prefs.setDebug(this@AutoPosterAccessibilityService, "Platform-Poll: ${e.javaClass.simpleName}: ${e.message}")
            }
            h.postDelayed(this, 700L)
        }
    }

    private val watchdog = object : Runnable {
        override fun run() {
            try { runWatchdog() } catch (e: Exception) {
                Prefs.setDebug(this@AutoPosterAccessibilityService, "Watchdog: ${e.javaClass.simpleName}: ${e.message}")
            }
            h.postDelayed(this, 2200L)
        }
    }

    private val chatPoll = object : Runnable {
        override fun run() {
            syncRunState()
            if (Prefs.getStage(this@AutoPosterAccessibilityService) == Prefs.STAGE_CHATGPT) {
                handleChatGpt(fromPoll = true)
            }
            h.postDelayed(this, 800L)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        recoveryEngine = RecoveryEngine(this)
        h.removeCallbacks(chatPoll)
        h.removeCallbacks(platformPoll)
        h.removeCallbacks(watchdog)
        h.postDelayed(chatPoll, 400L)
        h.postDelayed(platformPoll, 700L)
        h.postDelayed(watchdog, 1800L)
        EventLog.add(this, "SERVICE", "Accessibility verbunden")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        syncRunState()
        val pkg = event?.packageName?.toString().orEmpty()

        // Android's share resolver is not the ChatGPT package. When an image-only
        // share was deliberately opened from the verified image viewer, choose our
        // own receiver there. Never do this for the generic chat-share popup.
        if (imageSharePending && Prefs.getStage(this) == Prefs.STAGE_CHATGPT) {
            handleImageShareChooser()
        }

        if (pkg in setOf(PackageTargets.CHATGPT, PackageTargets.TIKTOK, PackageTargets.FACEBOOK, PackageTargets.YOUTUBE)) {
            Prefs.setLastPackage(this, pkg)
        }

        when (Prefs.getStage(this)) {
            Prefs.STAGE_CHATGPT -> {
                if (pkg == PackageTargets.CHATGPT) handleChatGpt(fromPoll = false)
            }
            Prefs.STAGE_WAIT_MEDIA -> handleWaitMedia(pkg)
            Prefs.STAGE_TIKTOK -> if (pkg == PackageTargets.TIKTOK) {
                handlePlatform(Prefs.STAGE_TIKTOK, Prefs.metadata(this).tiktokText(), listOf("Posten", "Post"))
            }
            Prefs.STAGE_FACEBOOK -> if (pkg == PackageTargets.FACEBOOK) {
                handlePlatform(Prefs.STAGE_FACEBOOK, Prefs.metadata(this).facebookText(), listOf("Posten", "Post", "Veröffentlichen", "Publish"))
            }
            Prefs.STAGE_YOUTUBE -> if (pkg == PackageTargets.YOUTUBE) handleYouTube()
            Prefs.STAGE_AI_REPAIR -> if (pkg == PackageTargets.CHATGPT) handleAiRepair()
        }
    }

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        h.removeCallbacks(chatPoll)
        h.removeCallbacks(platformPoll)
        h.removeCallbacks(watchdog)
        super.onDestroy()
    }

    private fun syncRunState() {
        val run = Prefs.getRunId(this)
        if (run == observedRunId) return
        observedRunId = run
        captureInFlight = false
        fallbackImageOpened = false
        fallbackSaveRequested = false
        downloadPollStarted = false
        platformCaptionFilled = false
        platformFinalClicked = false
        metadataScrollAttempts = 0
        imageScrollAttempts = 0
        captureFailures = 0
        lastActionAt = 0L
        lastRecoveryAt = 0L
        aiRequestSent = false
        aiSendClicked = false
        aiScreenshot = null
        sourceNavState = 0
        sourceNavLastAt = 0L
        saveRequestedAt = 0L
        tiktokEnteredAt = 0L
        tiktokAdvanceCount = 0
        tiktokLastAdvanceAt = 0L
        tiktokStableFp = ""
        tiktokStableSince = 0L
        imageTapPending = false
        imageTapAt = 0L
        imageViewerEnteredAt = 0L
        imageSharePending = false
        sourceTargetIndex = 0
        sidebarFallbackTaps = 0
        metadataScanPhase = 0
        metadataScanText = ""
        metadataScanSteps = 0
        metadataLastFp = ""
        metadataSameFpCount = 0
        metadataJumpToBottomTried = false
        Prefs.setDebug(this, "Neuer Lauf #$run erkannt")
    }

    /**
     * rootInActiveWindow can briefly point to MIUI launcher/overlays even when the
     * triggering event came from ChatGPT. Always select a window whose root really
     * belongs to the requested package.
     */
    private fun rootForPackage(pkg: String): AccessibilityNodeInfo? {
        try {
            windows.asReversed().forEach { w ->
                val r = w.root ?: return@forEach
                if (r.packageName?.toString() == pkg) return r
            }
        } catch (_: Exception) { }
        return rootInActiveWindow?.takeIf { it.packageName?.toString() == pkg }
    }

    private fun handleChatGpt(fromPoll: Boolean) {
        if (!ready(if (fromPoll) 500L else 250L)) return

        val root = rootForPackage(PackageTargets.CHATGPT)
        if (root == null) {
            Prefs.setStatus(this, "Warte auf ChatGPT-Fenster …")
            Prefs.setDebug(this, "Kein ChatGPT-Root gefunden; aktiver Root=${rootInActiveWindow?.packageName ?: "–"}")
            return
        }

        Prefs.setLastPackage(this, PackageTargets.CHATGPT)
        val all = collectText(root)

        // The screenshots from the real device showed that older builds could hit
        // ChatGPT's generic response/chat share button. Dismiss that state
        // immediately; it is never a valid way to obtain the generated image.
        if (isGenericChatSharePopup(all)) {
            performGlobalAction(GLOBAL_ACTION_BACK)
            imageTapPending = false
            fallbackImageOpened = false
            imageSharePending = false
            captureFailures++
            Prefs.setStatus(this, "Falschen Chat-Teilen-Dialog verworfen – Bild wird neu lokalisiert …")
            Prefs.setDebug(this, "Generic chat share popup erkannt und geschlossen")
            return
        }

        if (imageTapPending) {
            if (isVerifiedImageViewer(all)) {
                imageTapPending = false
                fallbackImageOpened = true
                imageViewerEnteredAt = System.currentTimeMillis()
                Prefs.setStatus(this, "Originalbild-Viewer bestätigt – suche Download/Teilen …")
                Prefs.setDebug(this, "Image viewer nach visueller Bildkoordinate verifiziert")
                Prefs.markProgress(this, "chatgpt-image-viewer-verified")
            } else if (System.currentTimeMillis() - imageTapAt < 1_800L) {
                return
            } else {
                imageTapPending = false
                captureFailures++
                Prefs.setStatus(this, "Bild-Tap nicht bestätigt – versuche erneut …")
                Prefs.setDebug(this, "Nach Bild-Tap blieb Chatansicht sichtbar; Versuch $captureFailures")
            }
        }

        if (!Prefs.hasMetadata(this)) {
            // Fast path: when one accessibility tree already contains every field.
            MetadataParser.parseComplete(
                all,
                Prefs.isTikTok(this),
                Prefs.isFacebook(this),
                Prefs.isYouTube(this)
            )?.let {
                Prefs.saveMetadata(this, it)
                Prefs.setStatus(this, "AUTOPOST-Daten vollständig erkannt. Suche Bild …")
                Prefs.setDebug(this, "Metadaten vollständig in einem ChatGPT-Fenster erkannt")
                toastOnce("AutoPoster: Text vollständig erkannt")
            }
        }

        if (!Prefs.hasMetadata(this)) {
            if (scanMetadataWithoutPingPong(root, all)) return
        }

        // V2.2: only act after the generated-image viewer was positively verified.
        // Prefer Download/Save. If this ChatGPT version exposes only image sharing,
        // share from the image viewer to AutoPoster's own receiver.
        if (fallbackImageOpened) {
            if (!fallbackSaveRequested && !imageSharePending) {
                if (clickByLabels(root, listOf("Herunterladen", "Download", "Download image", "Bild herunterladen", "Speichern", "Save image", "Bild speichern"), exactOnly = true)) {
                    fallbackSaveRequested = true
                    saveRequestedAt = System.currentTimeMillis()
                    Prefs.setStage(this, Prefs.STAGE_WAIT_MEDIA)
                    Prefs.setStatus(this, "Originalbild wird gespeichert …")
                    Prefs.setDebug(this, "Original-Download im verifizierten ChatGPT-Bildviewer ausgelöst")
                    startDownloadPoll()
                    return
                }

                if (imageViewerEnteredAt > 0L && System.currentTimeMillis() - imageViewerEnteredAt > 1_800L) {
                    if (clickByLabels(root, listOf("Teilen", "Share"), exactOnly = true)) {
                        imageSharePending = true
                        Prefs.setStatus(this, "Originalbild wird direkt an AutoPoster geteilt …")
                        Prefs.setDebug(this, "Image-viewer share ausgelöst; warte auf Android-Resolver")
                        return
                    }
                }
                Prefs.setStatus(this, "Bildviewer offen – suche Download oder Bild-Teilen …")
            }
            return
        }

        // V2.2: DO NOT click any generic accessibility "image-like" node. On the
        // real ChatGPT Compose screen those nodes can actually be the response/share
        // controls. Use the screenshot strictly as geometry, then tap the detected
        // 9:16 artwork and verify that the image viewer really opened.
        if (!captureInFlight && !imageTapPending) {
            val marker = findNodeContaining(root, "[AUTOPOST_V1]")
                ?: findNodeContaining(root, "[TIKTOK_TITLE]")
                ?: Prefs.metadata(this).tiktokTitle.take(28).takeIf { it.isNotBlank() }?.let { findNodeContaining(root, it) }
            val markerRect = marker?.let { Rect().also { r -> it.getBoundsInScreen(r) } }?.takeIf { it.width() > 20 && it.top > 100 }

            if (captureFailures < 5 && markerRect != null) {
                locateAndOpenOriginalImage(markerRect)
                return
            }

            if (imageScrollAttempts < 12 && scrollAny(root, forward = false)) {
                imageScrollAttempts++
                Prefs.setStatus(this, "Text erkannt – scrolle zum Originalbild …")
                Prefs.setDebug(this, "Metadaten da; Bildanker noch nicht lokalisierbar; Versuch $imageScrollAttempts")
                return
            }
        }

        // No generic ChatGPT share fallback here. Screenshot data is diagnostic
        // only; AutoPoster must obtain the original downloaded image before posting.
    }

    private fun locateAndOpenOriginalImage(markerBounds: Rect) {
        if (captureInFlight) return
        captureInFlight = true
        Prefs.setStatus(this, "Lokalisiere Originalbild …")
        Prefs.setDebug(this, "Screenshot nur zur Koordinatenerkennung; marker=$markerBounds")

        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(result: ScreenshotResult) {
                try {
                    val buffer = result.hardwareBuffer
                    val hw = Bitmap.wrapHardwareBuffer(buffer, result.colorSpace)
                    val full = hw?.copy(Bitmap.Config.ARGB_8888, false)
                    buffer.close()
                    if (full == null) throw IllegalStateException("Screenshot-Bitmap leer")
                    val chosen = detectImageRect(full, markerBounds)
                        ?: throw IllegalStateException("Kein plausibler Bildbereich erkannt")
                    val x = chosen.centerX().toFloat()
                    val y = chosen.centerY().toFloat()
                    full.recycle()
                    captureInFlight = false
                    if (!tapScreen(x, y)) throw IllegalStateException("Bild-Tap konnte nicht gesendet werden")
                    imageTapPending = true
                    imageTapAt = System.currentTimeMillis()
                    Prefs.setStatus(this@AutoPosterAccessibilityService, "Bild angetippt – prüfe, ob Original-Viewer geöffnet wurde …")
                    Prefs.setDebug(this@AutoPosterAccessibilityService, "Bild geometrisch an $x/$y angetippt; Screenshot verworfen; Viewer noch NICHT angenommen")
                    Prefs.markProgress(this@AutoPosterAccessibilityService, "chatgpt-image-tap-sent")
                } catch (e: Exception) {
                    captureInFlight = false
                    captureFailures++
                    Prefs.setStatus(this@AutoPosterAccessibilityService, "Originalbild-Lokalisierung ${captureFailures}/3 fehlgeschlagen")
                    Prefs.setDebug(this@AutoPosterAccessibilityService, "Bild-Locator #$captureFailures: ${e.javaClass.simpleName}: ${e.message}")
                    EventLog.add(this@AutoPosterAccessibilityService, "FAIL", "Bild-Locator #$captureFailures: ${e.message}")
                }
            }

            override fun onFailure(errorCode: Int) {
                captureInFlight = false
                captureFailures++
                Prefs.setStatus(this@AutoPosterAccessibilityService, "Bild-Lokalisierung nicht möglich – Recovery übernimmt")
                Prefs.setDebug(this@AutoPosterAccessibilityService, "Locator-Screenshot Fehlercode=$errorCode")
            }
        })
    }

    private fun tapScreen(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, 80L))
            .build()
        return dispatchGesture(gesture, null, null)
    }

    private fun clampRect(src: Rect, width: Int, height: Int): Rect? {
        if (width < 2 || height < 2) return null
        val left = src.left.coerceIn(0, width - 1)
        val top = src.top.coerceIn(0, height - 1)
        val right = src.right.coerceIn(left + 1, width)
        val bottom = src.bottom.coerceIn(top + 1, height)
        return Rect(left, top, right, bottom)
    }

    /**
     * Pixel fallback for ChatGPT Compose UI. The [AUTOPOST_V1] marker is directly
     * below the generated image in our task output. We search the area above that
     * marker for the nearest tall, dense non-background region and normalize it to
     * a 9:16 crop. Works in both dark and light ChatGPT themes.
     */
    /**
     * V2.4: ChatGPT/Compose can expose the whole assistant response as ONE
     * accessibility node. In that case the node containing [AUTOPOST_V1] starts
     * at the TOP OF THE IMAGE instead of at the visible marker text. V2.3 then
     * searched "above the marker" and could never see the artwork although it
     * was clearly visible on screen.
     *
     * Therefore the primary locator no longer trusts accessibility bounds. It
     * finds the largest tall, visually dense region directly in the screenshot.
     * The marker is only a secondary fallback.
     */
    private fun detectImageRect(bitmap: Bitmap, marker: Rect?): Rect? {
        detectLargestArtworkRect(bitmap)?.let {
            EventLog.add(this, "OK", "Bild visuell erkannt: $it")
            return it
        }
        if (marker != null) {
            markerAspectFallback(bitmap, marker)?.let {
                EventLog.add(this, "TRY", "Bild über Marker-Fallback: $it / marker=$marker")
                return it
            }
        }
        return null
    }

    /**
     * Finds the generated portrait artwork without relying on the accessibility
     * tree. We only need a reliable TAP TARGET, not a pixel-perfect crop.
     *
     * Strategy:
     * - estimate the ChatGPT page background from the right edge;
     * - ignore the status/navigation/composer zones;
     * - find long horizontal bands with lots of non-background pixels;
     * - merge tiny holes caused by bright sky/faded image edges;
     * - choose the tallest plausible band;
     * - inside that band find the widest dense column run;
     * - verify portrait-ish geometry and return its interior as a tap target.
     */
    private fun detectLargestArtworkRect(bitmap: Bitmap): Rect? {
        val w = bitmap.width
        val h = bitmap.height
        if (w < 240 || h < 480) return null

        val searchTop = (h * 0.075f).toInt().coerceAtLeast(1)
        val searchBottom = (h * 0.82f).toInt().coerceAtMost(h - 1)
        if (searchBottom - searchTop < 260) return null

        // Robust background estimate from several points near the far-right edge,
        // where the generated image does not sit in the real ChatGPT phone layout.
        val rs = mutableListOf<Int>()
        val gs = mutableListOf<Int>()
        val bs = mutableListOf<Int>()
        val xSamples = intArrayOf(
            (w * 0.94f).toInt(),
            (w * 0.97f).toInt(),
            (w * 0.985f).toInt()
        ).map { it.coerceIn(0, w - 1) }
        var sy = searchTop
        val sampleStep = ((searchBottom - searchTop) / 22).coerceAtLeast(1)
        while (sy < searchBottom) {
            for (sx in xSamples) {
                val c = bitmap.getPixel(sx, sy)
                rs += android.graphics.Color.red(c)
                gs += android.graphics.Color.green(c)
                bs += android.graphics.Color.blue(c)
            }
            sy += sampleStep
        }
        if (rs.isEmpty()) return null
        fun median(v: MutableList<Int>): Int {
            v.sort()
            return v[v.size / 2]
        }
        val br = median(rs)
        val bg = median(gs)
        val bb = median(bs)

        fun colorDistance(c: Int): Int =
            kotlin.math.abs(android.graphics.Color.red(c) - br) +
                kotlin.math.abs(android.graphics.Color.green(c) - bg) +
                kotlin.math.abs(android.graphics.Color.blue(c) - bb)

        // Row density. A full-width text line is made of thin glyphs and normally
        // stays below this density; a 9:16 artwork occupying ~50% screen width is
        // dense for hundreds of consecutive rows.
        val rowCount = searchBottom - searchTop
        val active = BooleanArray(rowCount)
        val xStep = 4
        for (yy in searchTop until searchBottom) {
            var diff = 0
            var total = 0
            var xx = (w * 0.02f).toInt()
            val xEnd = (w * 0.90f).toInt()
            while (xx < xEnd) {
                if (colorDistance(bitmap.getPixel(xx, yy)) > 58) diff++
                total++
                xx += xStep
            }
            val density = if (total == 0) 0f else diff.toFloat() / total
            active[yy - searchTop] = density >= 0.20f
        }

        // Close short inactive holes (bright sky, fade, thin overlays) inside an
        // otherwise continuous artwork band.
        val maxHole = (h * 0.018f).toInt().coerceIn(8, 34)
        var i = 0
        while (i < active.size) {
            if (active[i]) { i++; continue }
            val holeStart = i
            while (i < active.size && !active[i]) i++
            val holeEnd = i
            if (holeStart > 0 && holeEnd < active.size &&
                holeEnd - holeStart <= maxHole &&
                active[holeStart - 1] && active[holeEnd]
            ) {
                for (k in holeStart until holeEnd) active[k] = true
            }
        }

        data class Seg(val a: Int, val b: Int) {
            val len: Int get() = b - a
        }
        val rows = mutableListOf<Seg>()
        i = 0
        while (i < active.size) {
            if (!active[i]) { i++; continue }
            val a = i
            while (i < active.size && active[i]) i++
            val b = i
            val absA = searchTop + a
            val absB = searchTop + b
            if (absB - absA >= (h * 0.22f).toInt()) rows += Seg(absA, absB)
        }
        if (rows.isEmpty()) return null

        // Prefer a tall band, with a mild preference for the upper 2/3 where the
        // ChatGPT generated image sits in the actual task response.
        val row = rows.maxByOrNull {
            it.len - (it.a * 0.05f).toInt()
        } ?: return null

        // Determine horizontal bounds inside the central part of that row band.
        val insetY = (row.len * 0.08f).toInt().coerceAtLeast(2)
        val y1 = (row.a + insetY).coerceIn(0, h - 1)
        val y2 = (row.b - insetY).coerceIn(y1 + 1, h)
        val colActive = BooleanArray(w)
        val yStep = 5
        for (xx in 0 until w) {
            var diff = 0
            var total = 0
            var yy = y1
            while (yy < y2) {
                if (colorDistance(bitmap.getPixel(xx, yy)) > 58) diff++
                total++
                yy += yStep
            }
            val density = if (total == 0) 0f else diff.toFloat() / total
            colActive[xx] = density >= 0.32f
        }

        // Close tiny horizontal holes within the image.
        val maxColHole = (w * 0.018f).toInt().coerceIn(5, 18)
        i = 0
        while (i < colActive.size) {
            if (colActive[i]) { i++; continue }
            val a = i
            while (i < colActive.size && !colActive[i]) i++
            val b = i
            if (a > 0 && b < colActive.size && b - a <= maxColHole &&
                colActive[a - 1] && colActive[b]
            ) {
                for (k in a until b) colActive[k] = true
            }
        }

        val cols = mutableListOf<Seg>()
        i = 0
        while (i < colActive.size) {
            if (!colActive[i]) { i++; continue }
            val a = i
            while (i < colActive.size && colActive[i]) i++
            val b = i
            if (b - a >= (w * 0.28f).toInt()) cols += Seg(a, b)
        }
        val col = cols.maxByOrNull { it.len } ?: return null

        val rw = col.len
        val rh = row.len
        if (rw < w * 0.28f || rh < h * 0.22f) return null

        // The detected visual band can miss rounded/faded edges, so don't require
        // exact 9:16. We only reject clearly non-portrait regions.
        val ratio = rw.toFloat() / rh.toFloat()
        if (ratio !in 0.34f..0.90f) return null

        // Shrink a little to guarantee the tap lands inside the artwork, away from
        // rounded corners and neighboring response controls.
        val padX = (rw * 0.10f).toInt().coerceAtLeast(6)
        val padY = (rh * 0.10f).toInt().coerceAtLeast(8)
        val result = Rect(
            (col.a + padX).coerceIn(0, w - 2),
            (row.a + padY).coerceIn(0, h - 2),
            (col.b - padX).coerceIn(1, w),
            (row.b - padY).coerceIn(1, h)
        )
        if (result.width() < 80 || result.height() < 120) return null
        return result
    }

    private fun markerAspectFallback(bitmap: Bitmap, marker: Rect): Rect? {
        val w = bitmap.width; val h = bitmap.height
        val markerTop = marker.top.coerceIn(1, h)
        val left = marker.left.coerceIn(0, w - 2)
        var width = (w * 0.54f).toInt().coerceAtMost(w - left)
        var height = (width * 16f / 9f).toInt()
        val gap = (h * 0.010f).toInt().coerceAtLeast(6)
        val bottom = (markerTop - gap).coerceAtLeast(1)
        if (height > bottom) {
            height = bottom
            width = (height * 9f / 16f).toInt()
        }
        if (width < 120 || height < 160) return null
        return Rect(left, bottom - height, (left + width).coerceAtMost(w), bottom)
    }

    private fun handleWaitMedia(pkg: String) {
        if (fallbackSaveRequested && !downloadPollStarted) startDownloadPoll()
        if (pkg == PackageTargets.CHATGPT && !fallbackSaveRequested) {
            Prefs.setStage(this, Prefs.STAGE_CHATGPT)
            return
        }
    }

    private fun startDownloadPoll() {
        if (downloadPollStarted) return
        downloadPollStarted = true
        val started = saveRequestedAt.takeIf { it > 0L } ?: System.currentTimeMillis()
        var tries = 0
        fun poll() {
            if (Prefs.getStage(this) != Prefs.STAGE_WAIT_MEDIA) return
            tries++
            val media = try { MediaStoreHelper.latestRealImageAfter(this, started) } catch (_: SecurityException) { null }
            if (media != null) {
                val path = MediaStoreHelper.copyToCache(this, media.uri, media.mime)
                if (!path.isNullOrBlank()) {
                    Prefs.setMedia(this, path, media.mime)
                    Prefs.setStatus(this, "Originalbild übernommen. Starte Plattformen …")
                    Prefs.setDebug(this, "Original aus MediaStore: ${media.name} / ${media.relativePath}")
                    PostingOrchestrator.afterMediaCaptured(this)
                    return
                }
            }
            if (tries < 24) {
                h.postDelayed({ poll() }, 750)
            } else {
                downloadPollStarted = false
                fallbackSaveRequested = false
                Prefs.setStage(this, Prefs.STAGE_CHATGPT)
                Prefs.setStatus(this, "Speichern nicht erkannt")
                Prefs.setDebug(this, "Kein neues Bild nach explizitem Save gefunden")
            }
        }
        h.postDelayed({ poll() }, 700)
    }

    private fun handlePlatform(stage: String, text: String, finalLabels: List<String>) {
        if (!ready(450)) return
        val pkg = when (stage) {
            Prefs.STAGE_TIKTOK -> PackageTargets.TIKTOK
            Prefs.STAGE_FACEBOOK -> PackageTargets.FACEBOOK
            else -> return
        }
        val root = rootForPackage(pkg) ?: return

        if (stage == Prefs.STAGE_TIKTOK) {
            handleTikTok(root, text, finalLabels)
            return
        }

        if (!platformCaptionFilled) {
            val editable = findBestEditable(root)
            if (editable != null && text.isNotBlank()) {
                if (setText(editable, text)) {
                    platformCaptionFilled = true
                    Prefs.markProgress(this, "$stage-caption")
                    Prefs.setStatus(this, "$stage: Text eingefügt")
                    return
                }
            }
            if (clickByLabels(root, listOf("Weiter", "Next", "Fertig", "Done"))) return
        }

        if (platformCaptionFilled && !platformFinalClicked) {
            if (Prefs.isTestMode(this)) {
                Prefs.setStatus(this, "$stage Testmodus: vor dem finalen Post gestoppt")
                toastOnce("AutoPoster Testmodus: vor Post gestoppt")
                return
            }
            if (clickByLabels(root, finalLabels)) {
                platformFinalClicked = true
                Prefs.setStatus(this, "$stage: Veröffentlichung ausgelöst")
                PostingOrchestrator.finishPlatform(this, stage)
                resetPlatformFlagsLater()
            }
        }
    }

    private fun handleTikTok(root: AccessibilityNodeInfo, text: String, finalLabels: List<String>) {
        val now = System.currentTimeMillis()
        if (tiktokEnteredAt == 0L) {
            tiktokEnteredAt = now
            Prefs.markProgress(this, "tiktok-editor-entered")
        }

        // TikTok assigns/loads the recommended sound asynchronously. In v2.1 the
        // caption field was checked BEFORE the wait gate, so an editable field could
        // bypass the music delay entirely. V2.2 gates every automatic TikTok action.
        val minWait = 18_000L
        val elapsed = now - tiktokEnteredAt
        if (!platformCaptionFilled && elapsed < minWait) {
            val left = ((minWait - elapsed + 999L) / 1000L).coerceAtLeast(1L)
            Prefs.setStatus(this, "TikTok: warte auf automatische Musik … ${left}s")
            return
        }

        val editable = findBestEditable(root)
        if (!platformCaptionFilled && editable != null && text.isNotBlank()) {
            if (setText(editable, text)) {
                platformCaptionFilled = true
                Prefs.markProgress(this, "TIKTOK-caption")
                Prefs.setStatus(this, "TikTok: Text eingefügt – bereit zur Kontrolle")
                return
            }
        }

        if (!platformCaptionFilled) {
            // Require the editor tree to stay stable before advancing.
            val fp = fingerprint(PackageTargets.TIKTOK, "EDITOR", collectText(root))
            if (fp != tiktokStableFp) {
                tiktokStableFp = fp
                tiktokStableSince = now
                Prefs.setStatus(this, "TikTok: Musik/Editor stabilisiert sich …")
                return
            }
            if (now - tiktokStableSince < 2_500L) return
            if (now - tiktokLastAdvanceAt < 3_500L) return

            // Some TikTok versions have one editor step, others two.
            if (tiktokAdvanceCount < 2 && clickByLabels(root, listOf("Weiter", "Next", "Fertig", "Done"), exactOnly = true)) {
                tiktokAdvanceCount++
                tiktokLastAdvanceAt = now
                tiktokStableFp = ""
                tiktokStableSince = 0L
                Prefs.markProgress(this, "tiktok-next-$tiktokAdvanceCount")
                Prefs.setStatus(this, "TikTok: Weiter erst nach Musik-Wartezeit")
            }
            return
        }

        if (!platformFinalClicked) {
            if (Prefs.isTestMode(this)) {
                Prefs.setStatus(this, "TikTok Testmodus: vor Veröffentlichen gestoppt")
                toastOnce("AutoPoster Testmodus: vor TikTok-Post gestoppt")
                return
            }
            if (clickByLabels(root, finalLabels, exactOnly = true)) {
                platformFinalClicked = true
                Prefs.setStatus(this, "TikTok: Veröffentlichung ausgelöst")
                PostingOrchestrator.finishPlatform(this, Prefs.STAGE_TIKTOK)
                resetPlatformFlagsLater()
            }
        }
    }

    private fun handleYouTube() {
        if (!ready(550)) return
        val root = rootForPackage(PackageTargets.YOUTUBE) ?: return
        val text = Prefs.metadata(this).youtubeText()
        if (!platformCaptionFilled) {
            val editable = findBestEditable(root)
            if (editable != null && text.isNotBlank() && setText(editable, text)) {
                platformCaptionFilled = true
                Prefs.markProgress(this, "YOUTUBE-caption")
                Prefs.setStatus(this, "YouTube: Short-Titel/Text eingefügt")
                return
            }
            clickByLabels(root, listOf("Weiter", "Next", "Short erstellen", "Create a Short", "Kurzvideo erstellen"))
            return
        }
        if (Prefs.isTestMode(this)) {
            Prefs.setStatus(this, "YouTube Testmodus: vor Upload gestoppt")
            return
        }
        if (!platformFinalClicked && clickByLabels(root, listOf("Short hochladen", "Upload Short", "Hochladen", "Upload", "Posten", "Post"))) {
            platformFinalClicked = true
            Prefs.setStatus(this, "YouTube: Upload ausgelöst")
            PostingOrchestrator.finishPlatform(this, Prefs.STAGE_YOUTUBE)
            resetPlatformFlagsLater()
        }
    }

    private fun resetPlatformFlagsLater() {
        h.postDelayed({
            platformCaptionFilled = false
            platformFinalClicked = false
        }, 3500)
    }

    private fun runWatchdog() {
        syncRunState()
        if (!Prefs.isAutoRecovery(this)) return
        val stage = Prefs.getStage(this)
        if (stage in setOf(Prefs.STAGE_IDLE, Prefs.STAGE_DONE, Prefs.STAGE_AI_REPAIR)) return
        val now = System.currentTimeMillis()
        val last = Prefs.lastProgressAt(this)
        if (last <= 0L || now - last < 12_000L || now - lastRecoveryAt < 5_000L) return
        lastRecoveryAt = now
        val round = Prefs.incRecoveryRound(this)
        EventLog.add(this, "RECOVERY", "Runde $round in $stage")
        performRecovery(stage, round)
    }

    private fun performRecovery(stage: String, round: Int) {
        val pkg = when (stage) {
            Prefs.STAGE_CHATGPT, Prefs.STAGE_WAIT_MEDIA -> PackageTargets.CHATGPT
            Prefs.STAGE_TIKTOK -> PackageTargets.TIKTOK
            Prefs.STAGE_FACEBOOK -> PackageTargets.FACEBOOK
            Prefs.STAGE_YOUTUBE -> PackageTargets.YOUTUBE
            else -> ""
        }
        val root = if (pkg.isNotBlank()) rootForPackage(pkg) else null
        val text = root?.let { collectText(it) }.orEmpty()
        val fp = fingerprint(pkg, stage, text)
        Prefs.setScreenFingerprint(this, fp)
        val snap = RecoveryEngine.ContextSnapshot(stage, pkg, text, fp)
        val order = recoveryEngine.chooseOrder(this, snap)

        var used: String? = null
        for (strategy in order) {
            val ok = when (strategy) {
                "chat-scroll-up" -> recoveryEngine.scroll(root, forward = false)
                "chat-scroll-down" -> recoveryEngine.scroll(root, forward = true)
                "chat-reopen" -> recoveryEngine.reopen(PackageTargets.CHATGPT)
                "platform-next" -> {
                    // TikTok advancement is exclusively controlled by handleTikTok
                    // so Recovery can never race past the sound-loading delay.
                    if (stage == Prefs.STAGE_TIKTOK) false
                    else root?.let { clickByLabels(it, listOf("Weiter", "Next", "Fertig", "Done"), exactOnly = true) } ?: false
                }
                "platform-scroll" -> recoveryEngine.scroll(root, forward = true)
                "platform-reopen" -> recoveryEngine.reopen(pkg)
                "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
                "reopen" -> if (pkg.isNotBlank()) recoveryEngine.reopen(pkg) else false
                else -> false
            }
            if (ok) { used = strategy; break }
        }

        if (used != null) {
            Prefs.setStatus(this, "Recovery $round: $used")
            Prefs.setDebug(this, "Self-Healing: $used auf $stage / $fp")
            EventLog.add(this, "TRY", used)
            // Do not mark success yet. Strategy is remembered only when the stage later progresses.
            h.postDelayed({
                if (Prefs.lastProgressAt(this) > lastRecoveryAt) {
                    StrategyMemory.remember(this, pkg, stage, fp, used!!)
                }
            }, 4500L)
            return
        }

        if (round >= 3 && Prefs.isAiAssist(this)) {
            startAiRepair(stage, fp)
        } else {
            Prefs.setStatus(this, "Recovery $round: kein lokaler Weg – neuer Versuch folgt")
            Prefs.setDebug(this, "Alle lokalen Strategien für $stage ohne Aktion")
        }
    }

    private fun startAiRepair(stage: String, fp: String) {
        if (aiRequestSent) return
        aiRequestSent = true
        Prefs.setStatus(this, "Lokale Recovery erschöpft – ChatGPT Assist …")
        EventLog.add(this, "AI", "ChatGPT Assist für $stage gestartet")
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(result: ScreenshotResult) {
                try {
                    val buffer = result.hardwareBuffer
                    val hw = Bitmap.wrapHardwareBuffer(buffer, result.colorSpace)
                    val full = hw?.copy(Bitmap.Config.ARGB_8888, false)
                    buffer.close()
                    if (full != null) {
                        val f = File(cacheDir, "repair_${Prefs.getRunId(this@AutoPosterAccessibilityService)}.png")
                        FileOutputStream(f).use { full.compress(Bitmap.CompressFormat.PNG, 92, it) }
                        full.recycle(); aiScreenshot = f
                    }
                } catch (_: Exception) { }
                launchAiBridge(stage, fp)
            }
            override fun onFailure(errorCode: Int) { launchAiBridge(stage, fp) }
        })
    }

    private fun launchAiBridge(stage: String, fp: String) {
        val ok = ChatGptRepairBridge.launch(this, aiScreenshot, stage, fp, Prefs.debug(this))
        if (ok) {
            Prefs.setStage(this, Prefs.STAGE_AI_REPAIR)
            Prefs.setStatus(this, "ChatGPT Assist geöffnet – warte auf Reparaturplan …")
        } else {
            aiRequestSent = false
            Prefs.setStatus(this, "ChatGPT Assist konnte nicht geöffnet werden")
        }
    }

    private fun handleAiRepair() {
        if (!ready(700)) return
        val root = rootForPackage(PackageTargets.CHATGPT) ?: return
        val all = collectText(root)
        val commands = SafeAutofix.parse(all)
        if (commands.isNotEmpty()) {
            EventLog.add(this, "AI", "${commands.size} sichere Befehle empfangen")
            val originalStage = inferOriginalStageFromLog()
            executeSafeCommands(commands, originalStage)
            return
        }
        if (!aiSendClicked) {
            val editable = findBestEditable(root)
            // ACTION_SEND usually prefills the composer. Only click the send control; never tap generic Share.
            if (editable != null && clickByLabels(root, listOf("Senden", "Send", "Nachricht senden"))) {
                aiSendClicked = true
                Prefs.setStatus(this, "ChatGPT Assist: Reparaturanfrage gesendet")
                return
            }
        }
        scrollAny(root, forward = true)
    }

    private fun inferOriginalStageFromLog(): String {
        val log = EventLog.text(this)
        return when {
            log.contains(" in TIKTOK") -> Prefs.STAGE_TIKTOK
            log.contains(" in FACEBOOK") -> Prefs.STAGE_FACEBOOK
            log.contains(" in YOUTUBE") -> Prefs.STAGE_YOUTUBE
            else -> Prefs.STAGE_CHATGPT
        }
    }

    private fun executeSafeCommands(commands: List<SafeAutofix.Command>, returnStage: String) {
        val targetPkg = when (returnStage) {
            Prefs.STAGE_TIKTOK -> PackageTargets.TIKTOK
            Prefs.STAGE_FACEBOOK -> PackageTargets.FACEBOOK
            Prefs.STAGE_YOUTUBE -> PackageTargets.YOUTUBE
            else -> PackageTargets.CHATGPT
        }
        recoveryEngine.reopen(targetPkg)
        var delay = 1200L
        commands.forEach { cmd ->
            h.postDelayed({
                when (cmd) {
                    SafeAutofix.Command.ScrollUp -> rootInActiveWindow?.let { recoveryEngine.scroll(it, false) }
                    SafeAutofix.Command.ScrollDown -> rootInActiveWindow?.let { recoveryEngine.scroll(it, true) }
                    SafeAutofix.Command.Back -> performGlobalAction(GLOBAL_ACTION_BACK)
                    is SafeAutofix.Command.Wait -> Unit
                    is SafeAutofix.Command.TapText -> rootInActiveWindow?.let { clickByLabels(it, listOf(cmd.text)) }
                    is SafeAutofix.Command.Reopen -> {
                        val pkg = when (cmd.target) {
                            "chatgpt" -> PackageTargets.CHATGPT
                            "tiktok" -> PackageTargets.TIKTOK
                            "facebook" -> PackageTargets.FACEBOOK
                            "youtube" -> PackageTargets.YOUTUBE
                            else -> ""
                        }
                        if (pkg.isNotBlank()) recoveryEngine.reopen(pkg)
                    }
                }
            }, delay)
            delay += if (cmd is SafeAutofix.Command.Wait) cmd.seconds * 1000L else 900L
        }
        h.postDelayed({
            aiRequestSent = false; aiSendClicked = false
            Prefs.setStage(this, returnStage)
            Prefs.markProgress(this, "ai-repair-plan-executed")
            Prefs.setStatus(this, "ChatGPT-Reparaturplan ausgeführt – normaler Ablauf läuft weiter")
        }, delay + 800L)
    }

    private fun fingerprint(pkg: String, stage: String, text: String): String {
        val normalized = text.lowercase().replace(Regex("\\d+"), "#").replace(Regex("\\s+"), " ").take(500)
        val bytes = MessageDigest.getInstance("SHA-256").digest("$pkg|$stage|$normalized".toByteArray())
        return bytes.take(6).joinToString("") { "%02x".format(it) }
    }

    private fun ready(ms: Long = 350): Boolean {
        val n = System.currentTimeMillis()
        if (n - lastActionAt < ms) return false
        lastActionAt = n
        return true
    }

    /**
     * V2.3 deterministic metadata scan.
     *
     * The v2.2 code blindly performed seven backward scrolls and then three
     * forward scrolls. On the real ChatGPT Compose UI only the currently virtualized
     * portion of a long answer is exposed, so that produced exactly the observed
     * "hoch/runter und nichts passiert" behavior.
     *
     * New algorithm:
     * 1) Open the configured source chat.
     * 2) Seek the newest/bottom position only once.
     * 3) Scan upward only, prepending each viewport into a chronological transcript.
     * 4) Continue only after all fields required by the enabled platforms are present.
     */
    private fun scanMetadataWithoutPingPong(root: AccessibilityNodeInfo, all: String): Boolean {
        val targets = sourceTargets()
        Prefs.setStatus(this, "ChatGPT: lese neuesten AUTOPOST-Beitrag …")
        Prefs.setDebug(
            this,
            "Metadaten-Scan Phase=$metadataScanPhase Schritt=$metadataScanSteps; " +
                "Ziel=${targets.getOrNull(sourceTargetIndex) ?: "–"}; Text=${all.take(180)}"
        )

        if (sourceNavState < 4) {
            if (navigateToSourceChat(root)) return true
            return true
        }

        // Phase 0: first get to the latest end. Prefer ChatGPT's own jump-to-bottom
        // control, otherwise scroll forward until the viewport stops changing.
        if (metadataScanPhase == 0) {
            if (!metadataJumpToBottomTried) {
                metadataJumpToBottomTried = true
                if (clickByLabels(
                        root,
                        listOf(
                            "Scroll to bottom", "Jump to bottom", "Go to bottom",
                            "Zum Ende", "Ganz nach unten", "Nach unten"
                        ),
                        exactOnly = false
                    )
                ) {
                    metadataLastFp = ""
                    metadataSameFpCount = 0
                    metadataScanSteps++
                    Prefs.setStatus(this, "ChatGPT: springe zum neuesten Beitrag …")
                    return true
                }
            }

            val fp = fingerprint(PackageTargets.CHATGPT, "META-SEEK-BOTTOM", all)
            if (fp == metadataLastFp) metadataSameFpCount++ else metadataSameFpCount = 0
            metadataLastFp = fp

            val canTryMore = metadataScanSteps < 24 && metadataSameFpCount < 2
            if (canTryMore && scrollAny(root, forward = true)) {
                metadataScanSteps++
                Prefs.setStatus(this, "ChatGPT: suche Ende des neuesten Beitrags …")
                return true
            }

            // Bottom reached (or viewport stopped changing). Start one-way upward scan.
            metadataScanPhase = 1
            metadataScanText = all.takeLast(12_000)
            metadataScanSteps = 0
            metadataLastFp = ""
            metadataSameFpCount = 0
            Prefs.setStatus(this, "Neuester Bereich erreicht – lese AUTOPOST nach oben …")
            return true
        }

        // Phase 1: prepend the current viewport, because we're moving from bottom
        // toward the top and want the resulting transcript in natural reading order.
        val fp = fingerprint(PackageTargets.CHATGPT, "META-SCAN-UP", all)
        if (fp == metadataLastFp) {
            metadataSameFpCount++
        } else {
            metadataSameFpCount = 0
            metadataLastFp = fp
            metadataScanText = (all + "\n" + metadataScanText).take(48_000)
        }

        MetadataParser.parseComplete(
            metadataScanText,
            Prefs.isTikTok(this),
            Prefs.isFacebook(this),
            Prefs.isYouTube(this)
        )?.let {
            Prefs.saveMetadata(this, it)
            Prefs.setStatus(this, "AUTOPOST-Daten vollständig zusammengesetzt. Suche Originalbild …")
            Prefs.setDebug(this, "V2.3 Metadaten über ${metadataScanSteps + 1} Bildschirmbereiche zusammengesetzt")
            toastOnce("AutoPoster: kompletter AUTOPOST erkannt")
            return false
        }

        val sawMarker = metadataScanText.contains("[AUTOPOST_V1]", ignoreCase = true)
        val canTryMore = metadataScanSteps < 28 && metadataSameFpCount < 2
        if (canTryMore && scrollAny(root, forward = false)) {
            metadataScanSteps++
            Prefs.setStatus(
                this,
                if (sawMarker) "AUTOPOST gefunden – sammle noch fehlende Felder …"
                else "Suche Anfang des neuesten AUTOPOST-Beitrags …"
            )
            return true
        }

        // This source chat is exhausted. Try the scheduled-task fallback once.
        if (sourceTargetIndex + 1 < targets.size) {
            sourceTargetIndex++
            sourceNavState = 0
            metadataScanPhase = 0
            metadataScanText = ""
            metadataScanSteps = 0
            metadataLastFp = ""
            metadataSameFpCount = 0
            metadataJumpToBottomTried = false
            sidebarFallbackTaps = 0
            Prefs.setStatus(this, "Kein vollständiger AUTOPOST – versuche '${targets[sourceTargetIndex]}' …")
            Prefs.setDebug(this, "Quellchat gewechselt; vorher Marker=$sawMarker")
            return true
        }

        // Stop scrolling. The watchdog may then use recovery/AI assistance, but the
        // normal engine must never bounce the user up and down indefinitely.
        Prefs.setStatus(
            this,
            if (sawMarker) "AUTOPOST gefunden, aber Pflichtfelder fehlen – Recovery übernimmt …"
            else "Kein AUTOPOST im Quellchat gefunden – Recovery übernimmt …"
        )
        Prefs.setDebug(
            this,
            "Metadaten-Scan beendet: Marker=$sawMarker, Schritte=$metadataScanSteps, Buffer=${metadataScanText.length} Zeichen"
        )
        return true
    }

    /** Navigate to the configured source chat; if that chat does not contain the
     * task output, automatically fall back to the scheduled-task conversation. */
    private fun sourceTargets(): List<String> {
        val configured = Prefs.sourceChatName(this)
        return listOf(configured, "TikTok Content Maschine")
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .distinctBy { it.lowercase() }
    }

    private fun navigateToSourceChat(root: AccessibilityNodeInfo): Boolean {
        val now = System.currentTimeMillis()
        if (now - sourceNavLastAt < 650L) return false
        val targets = sourceTargets()
        if (targets.isEmpty()) return false
        sourceTargetIndex = sourceTargetIndex.coerceIn(0, targets.lastIndex)
        val target = targets[sourceTargetIndex]

        // If either known source title is visible in the sidebar/search results,
        // open the current target exactly.
        findExactNode(root, target)?.let { node ->
            if (clickNodeOrParent(node)) {
                sourceNavState = 4
                sourceNavLastAt = now
                metadataScrollAttempts = 0
                Prefs.setStatus(this, "ChatGPT: Quellchat '$target' geöffnet …")
                Prefs.markProgress(this, "source-chat-opened:$target")
                return true
            }
        }

        when (sourceNavState) {
            0 -> {
                if (clickByLabels(root, listOf("Open sidebar", "Seitenleiste öffnen", "Sidebar öffnen", "Chats öffnen", "Open chats", "Open navigation menu", "Navigation menu", "Menü", "Menu"), exactOnly = false)) {
                    sourceNavState = 1; sourceNavLastAt = now
                    Prefs.setStatus(this, "ChatGPT: öffne Chat-Liste …")
                    return true
                }
                // Compose sometimes exposes the hamburger only as an unlabeled icon.
                // Use the stable top-left navigation position as a guarded fallback.
                if (sidebarFallbackTaps < 2) {
                    val dm = resources.displayMetrics
                    if (tapScreen(dm.widthPixels * 0.085f, dm.heightPixels * 0.090f)) {
                        sidebarFallbackTaps++
                        sourceNavState = 1; sourceNavLastAt = now
                        Prefs.setStatus(this, "ChatGPT: Chat-Liste per Navigationssymbol geöffnet …")
                        return true
                    }
                }
                if (clickByLabels(root, listOf("Search", "Suchen", "Chats durchsuchen", "Search chats"), exactOnly = false)) {
                    sourceNavState = 2; sourceNavLastAt = now
                    return true
                }
            }
            1 -> {
                // Exact title branch above normally succeeds as soon as the sidebar
                // appears. If it is not in the recent list, open search.
                if (clickByLabels(root, listOf("Search", "Suchen", "Chats durchsuchen", "Search chats"), exactOnly = false)) {
                    sourceNavState = 2; sourceNavLastAt = now
                    Prefs.setStatus(this, "ChatGPT: suche Quellchat …")
                    return true
                }
                val dm = resources.displayMetrics
                if (tapScreen(dm.widthPixels * 0.68f, dm.heightPixels * 0.092f)) {
                    sourceNavState = 2; sourceNavLastAt = now
                    return true
                }
            }
            2 -> {
                val edit = findBestEditable(root)
                if (edit != null && setText(edit, target)) {
                    sourceNavState = 3; sourceNavLastAt = now
                    Prefs.setStatus(this, "ChatGPT: suche '$target' …")
                    return true
                }
            }
            3 -> {
                sourceNavLastAt = now
                return false
            }
        }
        return false
    }

    private fun findExactNode(root: AccessibilityNodeInfo, value: String): AccessibilityNodeInfo? {
        var found: AccessibilityNodeInfo? = null
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || found != null) return
            val t = n.text?.toString()?.trim().orEmpty()
            val d = n.contentDescription?.toString()?.trim().orEmpty()
            if (t.equals(value, true) || d.equals(value, true)) { found = n; return }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return found
    }

    private fun collectText(root: AccessibilityNodeInfo): String {
        val sb = StringBuilder()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            n.text?.toString()?.takeIf { it.isNotBlank() }?.let { sb.append(it).append('\n') }
            n.contentDescription?.toString()?.takeIf { it.isNotBlank() }?.let { sb.append(it).append('\n') }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return sb.toString()
    }

    private fun findNodeContaining(root: AccessibilityNodeInfo, token: String): AccessibilityNodeInfo? {
        var found: AccessibilityNodeInfo? = null
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || found != null) return
            val value = n.text?.toString().orEmpty() + " " + n.contentDescription?.toString().orEmpty()
            if (value.contains(token, ignoreCase = true)) {
                found = n
                return
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return found
    }

    /** Catch Compose/generic View containers that visually are a portrait image even
     * when neither className nor contentDescription says "image". */
    private fun largestPortraitNode(root: AccessibilityNodeInfo, markerTop: Int): AccessibilityNodeInfo? {
        var best: AccessibilityNodeInfo? = null
        var bestArea = 0L
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            val r = Rect(); n.getBoundsInScreen(r)
            val ww = r.width(); val hh = r.height()
            if (ww > 120 && hh > 180 && !n.isScrollable && r.top >= 0 && r.bottom <= markerTop + 60) {
                val ratio = hh.toFloat() / ww.toFloat()
                val area = ww.toLong() * hh.toLong()
                if (ratio in 1.35f..2.10f && area > bestArea) {
                    bestArea = area
                    best = n
                }
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return best
    }

    private fun largestImageLikeNode(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var best: AccessibilityNodeInfo? = null
        var area = 0L
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            val cls = n.className?.toString().orEmpty()
            val desc = n.contentDescription?.toString().orEmpty().lowercase()
            val text = n.text?.toString().orEmpty().lowercase()
            val likely = cls.contains("ImageView") || desc.contains("image") || desc.contains("bild") || desc.contains("generated") || text == "image" || text == "bild"
            if (likely) {
                val r = Rect()
                n.getBoundsInScreen(r)
                val a = r.width().toLong() * r.height().toLong()
                if (a > area && a > 40_000) {
                    area = a
                    best = n
                }
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return best
    }

    private fun findBestEditable(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val found = mutableListOf<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            val cls = n.className?.toString().orEmpty()
            if (n.isEditable || cls.contains("EditText")) found += n
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return found.maxByOrNull {
            val r = Rect()
            it.getBoundsInScreen(r)
            r.width().toLong() * r.height().toLong()
        }
    }

    private fun setText(n: AccessibilityNodeInfo, value: String): Boolean {
        val b = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, value)
        }
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    private fun scrollAny(root: AccessibilityNodeInfo, forward: Boolean): Boolean {
        val action = if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        val nodes = mutableListOf<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            if (n.isScrollable) nodes += n
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return nodes.asReversed().any { it.performAction(action) }
    }

    private fun clickByLabels(root: AccessibilityNodeInfo, labels: List<String>, exactOnly: Boolean = false): Boolean {
        val candidates = mutableListOf<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            val t = (n.text?.toString().orEmpty() + " " + n.contentDescription?.toString().orEmpty()).trim()
            if (labels.any { label -> t.equals(label, true) || (!exactOnly && t.contains(label, true)) }) candidates += n
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return candidates.asReversed().any { clickNodeOrParent(it) }
    }

    private fun clickNodeOrParent(node: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = node
        repeat(6) {
            if (n?.isClickable == true && n?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true) return true
            n = n?.parent
        }
        return false
    }


    private fun isGenericChatSharePopup(all: String): Boolean {
        val t = all.lowercase()
        return t.contains("link zum chat teilen") ||
            t.contains("eine kopie erstellt") ||
            t.contains("share link to chat") ||
            t.contains("create a copy")
    }

    private fun isVerifiedImageViewer(all: String): Boolean {
        val t = all.lowercase()
        if (isGenericChatSharePopup(all)) return false
        val markerVisible = t.contains("[autopost_v1]") || t.contains("[tiktok_title]")
        val viewerControl = listOf(
            "herunterladen", "download image", "bild herunterladen", "save image",
            "bild speichern", "download", "share image"
        ).any { t.contains(it) }
        // A successful image-viewer transition removes the long metadata response.
        // Accept sparse viewer UI even if icon labels are not exposed by Compose.
        return viewerControl || (!markerVisible && t.length < 700)
    }

    private fun handleImageShareChooser() {
        val root = rootInActiveWindow ?: return
        val all = collectText(root)
        if (isGenericChatSharePopup(all)) {
            imageSharePending = false
            performGlobalAction(GLOBAL_ACTION_BACK)
            return
        }
        val appNode = findExactNode(root, "AutoPoster")
        if (appNode != null && clickNodeOrParent(appNode)) {
            imageSharePending = false
            Prefs.setStatus(this, "Originalbild wird an AutoPoster übergeben …")
            Prefs.markProgress(this, "image-share-resolver-autoposter")
        }
    }
    private fun toastOnce(msg: String) {
        val now = System.currentTimeMillis()
        if (msg == lastToast && now - lastToastAt < 8_000L) return
        lastToast = msg
        lastToastAt = now
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
