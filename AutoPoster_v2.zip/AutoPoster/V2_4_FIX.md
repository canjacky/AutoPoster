# AutoPoster v2.4
- Fixes the real-device failure shown in the 18:40 diagnostic log:
  metadata-found succeeded, then Bild-Locator failed although artwork was visible.
- Cause: ChatGPT Compose can report [AUTOPOST_V1] inside one large semantics node
  whose bounds start at the image top. The old detector searched above that bound.
- Fix: primary image location is now fully visual and independent of marker bounds.
- Marker geometry remains only as a secondary fallback.
