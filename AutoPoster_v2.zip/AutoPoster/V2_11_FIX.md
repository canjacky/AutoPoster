# AutoPoster v2.11

TikTok-Fix:
- explizite URI-Leseberechtigung für TikTok vor ACTION_SEND
- erkennt TikTok Home/Posteingang, wenn der Share-Intent nicht den Composer öffnet
- öffnet automatisch den mittleren +/Create-Button
- öffnet Upload/Galerie
- wählt das neueste Foto (AutoPoster-Download)
- bestätigt Weiter/Next falls nötig
- startet die 18-Sekunden-Musikwartezeit erst im tatsächlichen Editor
- blockiert generische Recovery, solange der TikTok-Fotoimport läuft

Dateiname für GitHub bleibt AutoPoster_v2.zip.
