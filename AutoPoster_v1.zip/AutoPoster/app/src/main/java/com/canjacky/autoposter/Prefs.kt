package com.canjacky.autoposter

import android.content.Context

object Prefs {
    private const val NAME = "autoposter"
    private fun p(c: Context) = c.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    const val STAGE_IDLE = "IDLE"
    const val STAGE_CHATGPT = "CHATGPT"
    const val STAGE_WAIT_MEDIA = "WAIT_MEDIA"
    const val STAGE_TIKTOK = "TIKTOK"
    const val STAGE_FACEBOOK = "FACEBOOK"
    const val STAGE_YOUTUBE = "YOUTUBE"
    const val STAGE_DONE = "DONE"

    fun getStage(c: Context) = p(c).getString("stage", STAGE_IDLE) ?: STAGE_IDLE
    fun setStage(c: Context, v: String) = p(c).edit().putString("stage", v).apply()

    fun setStatus(c: Context, v: String) = p(c).edit().putString("status", v).apply()
    fun getStatus(c: Context) = p(c).getString("status", "Bereit") ?: "Bereit"

    fun bumpRunId(c: Context): Long {
        val next = p(c).getLong("run_id", 0L) + 1L
        p(c).edit()
            .putLong("run_id", next)
            .putLong("run_started_at", System.currentTimeMillis())
            .putBoolean("metadata_found", false)
            .putString("media_path", "")
            .putString("media_mime", "")
            .putString("last_package", "")
            .putString("last_debug", "")
            .remove("tt_title").remove("tt_desc").remove("tt_tags")
            .remove("fb_title").remove("fb_desc").remove("fb_tags")
            .remove("yt_title").remove("yt_desc").remove("yt_tags")
            .apply()
        return next
    }
    fun getRunId(c: Context) = p(c).getLong("run_id", 0L)
    fun runStartedAt(c: Context) = p(c).getLong("run_started_at", 0L)

    fun setLastPackage(c: Context, v: String) = p(c).edit().putString("last_package", v).apply()
    fun lastPackage(c: Context) = p(c).getString("last_package", "") ?: ""
    fun setDebug(c: Context, v: String) = p(c).edit().putString("last_debug", v).apply()
    fun debug(c: Context) = p(c).getString("last_debug", "") ?: ""

    fun setTestMode(c: Context, v: Boolean) = p(c).edit().putBoolean("test_mode", v).apply()
    fun isTestMode(c: Context) = p(c).getBoolean("test_mode", true)

    fun setTikTok(c: Context, v: Boolean) = p(c).edit().putBoolean("tiktok", v).apply()
    fun isTikTok(c: Context) = p(c).getBoolean("tiktok", true)
    fun setFacebook(c: Context, v: Boolean) = p(c).edit().putBoolean("facebook", v).apply()
    fun isFacebook(c: Context) = p(c).getBoolean("facebook", true)
    fun setYouTube(c: Context, v: Boolean) = p(c).edit().putBoolean("youtube", v).apply()
    fun isYouTube(c: Context) = p(c).getBoolean("youtube", true)
    fun setLatestMp4(c: Context, v: Boolean) = p(c).edit().putBoolean("latest_mp4", v).apply()
    fun useLatestMp4(c: Context) = p(c).getBoolean("latest_mp4", true)

    fun setMedia(c: Context, path: String, mime: String) = p(c).edit().putString("media_path", path).putString("media_mime", mime).apply()
    fun mediaPath(c: Context) = p(c).getString("media_path", "") ?: ""
    fun mediaMime(c: Context) = p(c).getString("media_mime", "") ?: ""

    fun saveMetadata(c: Context, m: PostMetadata) {
        p(c).edit()
            .putBoolean("metadata_found", true)
            .putString("tt_title", m.tiktokTitle).putString("tt_desc", m.tiktokDesc).putString("tt_tags", m.tiktokTags)
            .putString("fb_title", m.facebookTitle).putString("fb_desc", m.facebookDesc).putString("fb_tags", m.facebookTags)
            .putString("yt_title", m.youtubeTitle).putString("yt_desc", m.youtubeDesc).putString("yt_tags", m.youtubeTags)
            .apply()
    }
    fun hasMetadata(c: Context) = p(c).getBoolean("metadata_found", false)

    fun metadata(c: Context) = PostMetadata(
        p(c).getString("tt_title", "") ?: "", p(c).getString("tt_desc", "") ?: "", p(c).getString("tt_tags", "") ?: "",
        p(c).getString("fb_title", "") ?: "", p(c).getString("fb_desc", "") ?: "", p(c).getString("fb_tags", "") ?: "",
        p(c).getString("yt_title", "") ?: "", p(c).getString("yt_desc", "") ?: "", p(c).getString("yt_tags", "") ?: ""
    )
}
