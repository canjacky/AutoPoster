package com.canjacky.autoposter

import android.content.Context

object Prefs {
    private const val NAME = "autoposter"
    private fun p(c: Context) = c.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    const val STAGE_IDLE = "IDLE"
    const val STAGE_CHATGPT = "CHATGPT"
    const val STAGE_WAIT_MEDIA = "WAIT_MEDIA"
    const val STAGE_TIKTOK = "TIKTOK"
    const val STAGE_FACEBOOK = "FACEBOOK"
    const val STAGE_YOUTUBE = "YOUTUBE"
    const val STAGE_DONE = "DONE"

    var stage: String
        get() = throw UnsupportedOperationException("Use getStage(context)")
        set(_) = Unit

    fun getStage(c: Context) = p(c).getString("stage", STAGE_IDLE) ?: STAGE_IDLE
    fun setStage(c: Context, v: String) = p(c).edit().putString("stage", v).apply()

    fun setStatus(c: Context, v: String) = p(c).edit().putString("status", v).apply()
    fun getStatus(c: Context) = p(c).getString("status", "Bereit") ?: "Bereit"

    fun setTestMode(c: Context, v: Boolean) = p(c).edit().putBoolean("test_mode", v).apply()
    fun isTestMode(c: Context) = p(c).getBoolean("test_mode", true)

    fun setTikTok(c: Context, v: Boolean) = p(c).edit().putBoolean("tiktok", v).apply()
    fun isTikTok(c: Context) = p(c).getBoolean("tiktok", true)
    fun setFacebook(c: Context, v: Boolean) = p(c).edit().putBoolean("facebook", v).apply()
    fun isFacebook(c: Context) = p(c).getBoolean("facebook", true)
    fun setYouTube(c: Context, v: Boolean) = p(c).edit().putBoolean("youtube", v).apply()
    fun isYouTube(c: Context) = p(c).getBoolean("youtube", true)
    fun setLatestMp4(c: Context, v: Boolean) = p(c).edit().putBoolean("latest_mp4", v).apply()
    fun useLatestMp4(c: Context) = p(c).getBoolean("latest_mp4", true)

    fun setMedia(c: Context, path: String, mime: String) = p(c).edit().putString("media_path", path).putString("media_mime", mime).apply()
    fun mediaPath(c: Context) = p(c).getString("media_path", "") ?: ""
    fun mediaMime(c: Context) = p(c).getString("media_mime", "") ?: ""

    fun saveMetadata(c: Context, m: PostMetadata) {
        p(c).edit()
            .putString("tt_title", m.tiktokTitle).putString("tt_desc", m.tiktokDesc).putString("tt_tags", m.tiktokTags)
            .putString("fb_title", m.facebookTitle).putString("fb_desc", m.facebookDesc).putString("fb_tags", m.facebookTags)
            .putString("yt_title", m.youtubeTitle).putString("yt_desc", m.youtubeDesc).putString("yt_tags", m.youtubeTags)
            .apply()
    }

    fun metadata(c: Context) = PostMetadata(
        p(c).getString("tt_title", "") ?: "", p(c).getString("tt_desc", "") ?: "", p(c).getString("tt_tags", "") ?: "",
        p(c).getString("fb_title", "") ?: "", p(c).getString("fb_desc", "") ?: "", p(c).getString("fb_tags", "") ?: "",
        p(c).getString("yt_title", "") ?: "", p(c).getString("yt_desc", "") ?: "", p(c).getString("yt_tags", "") ?: ""
    )
}
