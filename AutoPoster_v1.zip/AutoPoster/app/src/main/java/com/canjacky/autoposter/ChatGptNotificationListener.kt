package com.canjacky.autoposter

import android.app.PendingIntent
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class ChatGptNotificationListener : NotificationListenerService() {
    companion object {
        @Volatile var latestChatGptIntent: PendingIntent? = null
        @Volatile var latestChatGptTitle: String = ""
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn?.packageName != PackageTargets.CHATGPT) return
        latestChatGptIntent = sbn.notification.contentIntent
        latestChatGptTitle = sbn.notification.extras?.getCharSequence("android.title")?.toString().orEmpty()
    }
}
