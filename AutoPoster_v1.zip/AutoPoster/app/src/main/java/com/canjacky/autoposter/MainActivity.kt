package com.canjacky.autoposter

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildUi())
        requestNeededPermissions()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun refreshStatus() {
        if (::status.isInitialized) {
            status.text = buildString {
                append("Status: ").append(Prefs.getStatus(this@MainActivity))
                append("\nStufe: ").append(Prefs.getStage(this@MainActivity))
                append("\nLetzte App: ").append(Prefs.lastPackage(this@MainActivity).ifBlank { "–" })
                append("\nDiagnose: ").append(Prefs.debug(this@MainActivity).ifBlank { "–" })
            }
        }
    }

    private fun buildUi(): ScrollView {
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 48, 48, 48)
        }
        scroll.addView(box)

        box.addView(TextView(this).apply {
            text = "AUTOPOSTER v1.1"
            textSize = 30f
            setTextColor(Color.BLACK)
        })
        box.addView(TextView(this).apply {
            text = "ChatGPT → TikTok → Facebook → YouTube Shorts"
            textSize = 16f
            setPadding(0, 4, 0, 28)
        })

        val test = CheckBox(this).apply {
            text = "Testmodus (vor dem finalen Post/Upload stoppen)"
            isChecked = Prefs.isTestMode(this@MainActivity)
            setOnCheckedChangeListener { _, v -> Prefs.setTestMode(this@MainActivity, v) }
        }
        box.addView(test)

        fun platform(label: String, checked: Boolean, change: (Boolean)->Unit): CheckBox = CheckBox(this).apply {
            text = label; isChecked = checked; setOnCheckedChangeListener { _, v -> change(v) }
        }
        box.addView(platform("TikTok", Prefs.isTikTok(this)) { Prefs.setTikTok(this, it) })
        box.addView(platform("Facebook", Prefs.isFacebook(this)) { Prefs.setFacebook(this, it) })
        box.addView(platform("YouTube Shorts (nur Video)", Prefs.isYouTube(this)) { Prefs.setYouTube(this, it) })
        box.addView(platform("Für YouTube das neueste MP4 vom Handy nehmen, falls ChatGPT nur ein Bild liefert", Prefs.useLatestMp4(this)) { Prefs.setLatestMp4(this, it) })

        status = TextView(this).apply {
            textSize = 15f
            setPadding(0, 28, 0, 28)
        }
        box.addView(status)

        box.addView(Button(this).apply {
            text = "STATUS AKTUALISIEREN"
            setOnClickListener { refreshStatus() }
        }, params())

        box.addView(Button(this).apply {
            text = "1. Bedienungshilfe aktivieren"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }, params())

        box.addView(Button(this).apply {
            text = "2. ChatGPT-Benachrichtigungen erlauben"
            setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        }, params())

        box.addView(Button(this).apply {
            text = "JETZT POSTEN"
            textSize = 22f
            setOnClickListener {
                PostingOrchestrator.start(this@MainActivity)
                refreshStatus()
            }
        }, params(92))

        box.addView(Button(this).apply {
            text = "Zurücksetzen"
            setOnClickListener {
                Prefs.bumpRunId(this@MainActivity)
                Prefs.setStage(this@MainActivity, Prefs.STAGE_IDLE)
                Prefs.setStatus(this@MainActivity, "Bereit")
                refreshStatus()
            }
        }, params())

        box.addView(TextView(this).apply {
            text = "V1.1: setzt jeden Lauf sauber zurück, sucht den AUTOPOST-Block durch Scrollen, versucht zuerst das ChatGPT-Bild zu speichern und nutzt Teilen als Fallback. Testmodus standardmäßig an."
            textSize = 13f
            setPadding(0, 24, 0, 0)
        })
        return scroll
    }

    private fun params(h: Int = 68) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h.dp()).apply {
        setMargins(0, 8.dp(), 0, 8.dp())
        gravity = Gravity.CENTER_HORIZONTAL
    }
    private fun Int.dp() = (this * resources.displayMetrics.density).toInt()

    private fun requestNeededPermissions() {
        val req = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) req += Manifest.permission.POST_NOTIFICATIONS
            if (checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES) != PackageManager.PERMISSION_GRANTED) req += Manifest.permission.READ_MEDIA_IMAGES
            if (checkSelfPermission(Manifest.permission.READ_MEDIA_VIDEO) != PackageManager.PERMISSION_GRANTED) req += Manifest.permission.READ_MEDIA_VIDEO
        } else {
            if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) req += Manifest.permission.READ_EXTERNAL_STORAGE
        }
        if (req.isNotEmpty()) requestPermissions(req.toTypedArray(), 100)
    }
}
