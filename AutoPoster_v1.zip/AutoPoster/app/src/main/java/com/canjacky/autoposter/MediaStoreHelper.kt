package com.canjacky.autoposter

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore

object MediaStoreHelper {
    fun latestVideo(c: Context): Uri? {
        val projection = arrayOf(MediaStore.Video.Media._ID)
        val sort = "${MediaStore.Video.Media.DATE_ADDED} DESC"
        c.contentResolver.query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, projection, null, null, sort)?.use { cur ->
            if (cur.moveToFirst()) {
                val id = cur.getLong(cur.getColumnIndexOrThrow(MediaStore.Video.Media._ID))
                return ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id)
            }
        }
        return null
    }
}
