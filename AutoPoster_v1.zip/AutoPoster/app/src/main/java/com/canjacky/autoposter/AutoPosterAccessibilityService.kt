package com.canjacky.autoposter

import android.accessibilityservice.AccessibilityService
import android.graphics.Rect
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class AutoPosterAccessibilityService : AccessibilityService() {
    private val h = Handler(Looper.getMainLooper())
    private var lastActionAt = 0L
    private var chatImageOpened = false
    private var chatShareRequested = false
    private var platformCaptionFilled = false
    private var platformFinalClicked = false

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString().orEmpty()
        when (Prefs.getStage(this)) {
            Prefs.STAGE_CHATGPT -> if (pkg == PackageTargets.CHATGPT) handleChatGpt(pkg)
            Prefs.STAGE_WAIT_MEDIA -> handleChatGpt(pkg)
            Prefs.STAGE_TIKTOK -> if (pkg == PackageTargets.TIKTOK) handlePlatform(Prefs.STAGE_TIKTOK, Prefs.metadata(this).tiktokText(), listOf("Posten", "Post"))
            Prefs.STAGE_FACEBOOK -> if (pkg == PackageTargets.FACEBOOK) handlePlatform(Prefs.STAGE_FACEBOOK, Prefs.metadata(this).facebookText(), listOf("Posten", "Post", "Veröffentlichen", "Publish"))
            Prefs.STAGE_YOUTUBE -> if (pkg == PackageTargets.YOUTUBE) handleYouTube()
        }
    }

    override fun onInterrupt() = Unit

    private fun handleChatGpt(pkg: String) {
        if (!ready()) return
        val root = rootInActiveWindow ?: return
        if (pkg == PackageTargets.CHATGPT) {
            val all = collectText(root)
            MetadataParser.parse(all)?.let {
                Prefs.saveMetadata(this, it)
                Prefs.setStatus(this, "Texte erkannt. Übernehme Bild/Video …")
            }
            if (!chatImageOpened) {
                val image = largestImageLikeNode(root)
                if (image != null && clickNodeOrParent(image)) {
                    chatImageOpened = true
                    h.postDelayed({ chatShareRequested = false }, 1200)
                    return
                }
            }
            if (chatImageOpened && !chatShareRequested) {
                if (clickByLabels(root, listOf("Teilen", "Share"))) {
                    chatShareRequested = true
                    Prefs.setStage(this, Prefs.STAGE_WAIT_MEDIA)
                    Prefs.setStatus(this, "Teile das Medium an AutoPoster …")
                    return
                }
                clickByLabels(root, listOf("Download", "Herunterladen", "Speichern", "Save"))
            }
        } else {
            // Android sharesheet: select our receiver automatically.
            if (clickByLabels(root, listOf("AutoPoster"))) return
        }
    }

    private fun handlePlatform(stage: String, text: String, finalLabels: List<String>) {
        if (!ready(550)) return
        val root = rootInActiveWindow ?: return
        if (!platformCaptionFilled) {
            val editable = findEditable(root)
            if (editable != null && text.isNotBlank()) {
                if (setText(editable, text)) {
                    platformCaptionFilled = true
                    Prefs.setStatus(this, "$stage: Text eingefügt")
                    return
                }
            }
            // Common media/edit screens before the caption form.
            if (clickByLabels(root, listOf("Weiter", "Next", "Fertig", "Done"))) return
        }
        if (platformCaptionFilled && !platformFinalClicked) {
            if (Prefs.isTestMode(this)) {
                Prefs.setStatus(this, "$stage Testmodus: vor dem finalen Post gestoppt")
                return
            }
            if (clickByLabels(root, finalLabels)) {
                platformFinalClicked = true
                Prefs.setStatus(this, "$stage: Veröffentlichung ausgelöst")
                PostingOrchestrator.finishPlatform(this, stage)
                resetPlatformFlagsLater()
            }
        }
    }

    private fun handleYouTube() {
        if (!ready(550)) return
        val root = rootInActiveWindow ?: return
        val text = Prefs.metadata(this).youtubeText()
        if (!platformCaptionFilled) {
            val editable = findEditable(root)
            if (editable != null && text.isNotBlank() && setText(editable, text)) {
                platformCaptionFilled = true
                Prefs.setStatus(this, "YouTube: Short-Titel/Text eingefügt")
                return
            }
            clickByLabels(root, listOf("Weiter", "Next", "Short erstellen", "Create a Short", "Kurzvideo erstellen"))
            return
        }
        if (Prefs.isTestMode(this)) {
            Prefs.setStatus(this, "YouTube Testmodus: vor Upload gestoppt")
            return
        }
        if (!platformFinalClicked && clickByLabels(root, listOf("Short hochladen", "Upload Short", "Hochladen", "Upload", "Posten", "Post"))) {
            platformFinalClicked = true
            Prefs.setStatus(this, "YouTube: Upload ausgelöst")
            PostingOrchestrator.finishPlatform(this, Prefs.STAGE_YOUTUBE)
            resetPlatformFlagsLater()
        }
    }

    private fun resetPlatformFlagsLater() {
        h.postDelayed({ platformCaptionFilled = false; platformFinalClicked = false }, 3500)
    }

    private fun ready(ms: Long = 350): Boolean {
        val n = System.currentTimeMillis()
        if (n - lastActionAt < ms) return false
        lastActionAt = n
        return true
    }

    private fun collectText(root: AccessibilityNodeInfo): String {
        val sb = StringBuilder()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            n.text?.toString()?.takeIf { it.isNotBlank() }?.let { sb.append(it).append('\n') }
            n.contentDescription?.toString()?.takeIf { it.isNotBlank() }?.let { sb.append(it).append('\n') }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return sb.toString()
    }

    private fun largestImageLikeNode(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var best: AccessibilityNodeInfo? = null
        var area = 0L
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            val cls = n.className?.toString().orEmpty()
            val desc = n.contentDescription?.toString().orEmpty().lowercase()
            val likely = cls.contains("ImageView") || desc.contains("image") || desc.contains("bild") || desc.contains("generated")
            if (likely) {
                val r = Rect(); n.getBoundsInScreen(r)
                val a = r.width().toLong() * r.height().toLong()
                if (a > area && a > 120_000) { area = a; best = n }
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return best
    }

    private fun findEditable(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var found: AccessibilityNodeInfo? = null
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || found != null) return
            val cls = n.className?.toString().orEmpty()
            if (n.isEditable || cls.contains("EditText")) { found = n; return }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return found
    }

    private fun setText(n: AccessibilityNodeInfo, value: String): Boolean {
        val b = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, value) }
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    private fun clickByLabels(root: AccessibilityNodeInfo, labels: List<String>): Boolean {
        val candidates = mutableListOf<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            val t = (n.text?.toString().orEmpty() + " " + n.contentDescription?.toString().orEmpty()).trim()
            if (labels.any { label -> t.equals(label, true) || t.contains(label, true) }) candidates += n
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return candidates.asReversed().any { clickNodeOrParent(it) }
    }

    private fun clickNodeOrParent(node: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = node
        repeat(5) {
            if (n?.isClickable == true && n?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true) return true
            n = n?.parent
        }
        return false
    }
}
