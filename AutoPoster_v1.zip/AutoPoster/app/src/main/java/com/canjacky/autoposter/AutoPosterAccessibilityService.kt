package com.canjacky.autoposter

import android.accessibilityservice.AccessibilityService
import android.graphics.Rect
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

class AutoPosterAccessibilityService : AccessibilityService() {
    private val h = Handler(Looper.getMainLooper())
    private var lastActionAt = 0L
    private var observedRunId = -1L
    private var chatImageOpened = false
    private var chatShareRequested = false
    private var downloadRequested = false
    private var downloadPollStarted = false
    private var platformCaptionFilled = false
    private var platformFinalClicked = false
    private var metadataScrollAttempts = 0
    private var imageScrollAttempts = 0
    private var lastToast = ""
    private var lastToastAt = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        syncRunState()
        val pkg = event?.packageName?.toString().orEmpty()
        if (pkg.isNotBlank()) Prefs.setLastPackage(this, pkg)
        when (Prefs.getStage(this)) {
            Prefs.STAGE_CHATGPT -> if (pkg == PackageTargets.CHATGPT) handleChatGpt()
            Prefs.STAGE_WAIT_MEDIA -> handleWaitMedia(pkg)
            Prefs.STAGE_TIKTOK -> if (pkg == PackageTargets.TIKTOK) handlePlatform(Prefs.STAGE_TIKTOK, Prefs.metadata(this).tiktokText(), listOf("Posten", "Post"))
            Prefs.STAGE_FACEBOOK -> if (pkg == PackageTargets.FACEBOOK) handlePlatform(Prefs.STAGE_FACEBOOK, Prefs.metadata(this).facebookText(), listOf("Posten", "Post", "Veröffentlichen", "Publish"))
            Prefs.STAGE_YOUTUBE -> if (pkg == PackageTargets.YOUTUBE) handleYouTube()
        }
    }

    override fun onInterrupt() = Unit

    private fun syncRunState() {
        val run = Prefs.getRunId(this)
        if (run == observedRunId) return
        observedRunId = run
        chatImageOpened = false
        chatShareRequested = false
        downloadRequested = false
        downloadPollStarted = false
        platformCaptionFilled = false
        platformFinalClicked = false
        metadataScrollAttempts = 0
        imageScrollAttempts = 0
        lastActionAt = 0L
        Prefs.setDebug(this, "Neuer Lauf #$run erkannt")
    }

    private fun handleChatGpt() {
        if (!ready()) return
        val root = rootInActiveWindow ?: return
        val all = collectText(root)

        if (!Prefs.hasMetadata(this)) {
            MetadataParser.parse(all)?.let {
                Prefs.saveMetadata(this, it)
                Prefs.setStatus(this, "AUTOPOST-Daten erkannt. Suche Bild …")
                Prefs.setDebug(this, "Metadaten erkannt")
                toastOnce("AutoPoster: Text erkannt")
            }
        }

        if (!Prefs.hasMetadata(this)) {
            Prefs.setStatus(this, "ChatGPT offen – suche [AUTOPOST_V1] …")
            Prefs.setDebug(this, "AUTOPOST-Block noch nicht sichtbar; Text=${all.take(180)}")
            if (metadataScrollAttempts < 8 && scrollAny(root, forward = true)) {
                metadataScrollAttempts++
                return
            }
            if (metadataScrollAttempts < 12 && scrollAny(root, forward = false)) {
                metadataScrollAttempts++
                return
            }
            toastOnce("AutoPoster: AUTOPOST-Text noch nicht gefunden")
            return
        }

        if (!chatImageOpened) {
            val image = largestImageLikeNode(root)
            if (image != null && clickNodeOrParent(image)) {
                chatImageOpened = true
                Prefs.setStatus(this, "Bild geöffnet …")
                Prefs.setDebug(this, "Bildknoten geöffnet")
                return
            }
            if (imageScrollAttempts < 8 && scrollAny(root, forward = false)) {
                imageScrollAttempts++
                Prefs.setStatus(this, "Text erkannt – suche das zugehörige Bild …")
                return
            }
            toastOnce("AutoPoster: Text da, Bild noch nicht gefunden")
            return
        }

        if (!downloadRequested) {
            if (clickByLabels(root, listOf("Herunterladen", "Download", "Speichern", "Save image", "Bild speichern", "Save"))) {
                downloadRequested = true
                Prefs.setStage(this, Prefs.STAGE_WAIT_MEDIA)
                Prefs.setStatus(this, "Bild wird gespeichert …")
                Prefs.setDebug(this, "Download/Speichern geklickt")
                startDownloadPoll()
                return
            }
        }

        if (!chatShareRequested) {
            if (clickByLabels(root, listOf("Teilen", "Share"))) {
                chatShareRequested = true
                Prefs.setStage(this, Prefs.STAGE_WAIT_MEDIA)
                Prefs.setStatus(this, "Teile das Bild an AutoPoster …")
                Prefs.setDebug(this, "Share-Fallback geklickt")
                return
            }
        }
    }

    private fun handleWaitMedia(pkg: String) {
        if (downloadRequested && !downloadPollStarted) startDownloadPoll()
        if (pkg == PackageTargets.CHATGPT) {
            // Ein später Event kann den Save-Dialog sichtbar machen.
            if (!downloadRequested) handleChatGpt()
            return
        }
        val root = rootInActiveWindow ?: return
        if (clickByLabels(root, listOf("AutoPoster"))) {
            Prefs.setDebug(this, "AutoPoster im Sharesheet gewählt")
        }
    }

    private fun startDownloadPoll() {
        if (downloadPollStarted) return
        downloadPollStarted = true
        val started = Prefs.runStartedAt(this)
        var tries = 0
        fun poll() {
            if (Prefs.getStage(this) != Prefs.STAGE_WAIT_MEDIA) return
            tries++
            val uri = try { MediaStoreHelper.latestImageAfter(this, started) } catch (_: SecurityException) { null }
            if (uri != null) {
                val path = MediaStoreHelper.copyToCache(this, uri, "image/jpeg")
                if (!path.isNullOrBlank()) {
                    Prefs.setMedia(this, path, "image/jpeg")
                    Prefs.setStatus(this, "Bild übernommen. Starte Plattformen …")
                    Prefs.setDebug(this, "Gespeichertes Bild aus MediaStore übernommen")
                    PostingOrchestrator.afterMediaCaptured(this)
                    return
                }
            }
            if (tries < 24) {
                h.postDelayed({ poll() }, 750)
            } else {
                downloadPollStarted = false
                downloadRequested = false
                Prefs.setStage(this, Prefs.STAGE_CHATGPT)
                Prefs.setStatus(this, "Speichern nicht erkannt – versuche Teilen …")
                Prefs.setDebug(this, "Kein neues Bild nach Save gefunden; Share-Fallback")
                h.postDelayed({ handleChatGpt() }, 400)
            }
        }
        h.postDelayed({ poll() }, 700)
    }

    private fun handlePlatform(stage: String, text: String, finalLabels: List<String>) {
        if (!ready(550)) return
        val root = rootInActiveWindow ?: return
        if (!platformCaptionFilled) {
            val editable = findBestEditable(root)
            if (editable != null && text.isNotBlank()) {
                if (setText(editable, text)) {
                    platformCaptionFilled = true
                    Prefs.setStatus(this, "$stage: Text eingefügt")
                    return
                }
            }
            if (clickByLabels(root, listOf("Weiter", "Next", "Fertig", "Done"))) return
        }
        if (platformCaptionFilled && !platformFinalClicked) {
            if (Prefs.isTestMode(this)) {
                Prefs.setStatus(this, "$stage Testmodus: vor dem finalen Post gestoppt")
                toastOnce("AutoPoster Testmodus: vor Post gestoppt")
                return
            }
            if (clickByLabels(root, finalLabels)) {
                platformFinalClicked = true
                Prefs.setStatus(this, "$stage: Veröffentlichung ausgelöst")
                PostingOrchestrator.finishPlatform(this, stage)
                resetPlatformFlagsLater()
            }
        }
    }

    private fun handleYouTube() {
        if (!ready(550)) return
        val root = rootInActiveWindow ?: return
        val text = Prefs.metadata(this).youtubeText()
        if (!platformCaptionFilled) {
            val editable = findBestEditable(root)
            if (editable != null && text.isNotBlank() && setText(editable, text)) {
                platformCaptionFilled = true
                Prefs.setStatus(this, "YouTube: Short-Titel/Text eingefügt")
                return
            }
            clickByLabels(root, listOf("Weiter", "Next", "Short erstellen", "Create a Short", "Kurzvideo erstellen"))
            return
        }
        if (Prefs.isTestMode(this)) {
            Prefs.setStatus(this, "YouTube Testmodus: vor Upload gestoppt")
            return
        }
        if (!platformFinalClicked && clickByLabels(root, listOf("Short hochladen", "Upload Short", "Hochladen", "Upload", "Posten", "Post"))) {
            platformFinalClicked = true
            Prefs.setStatus(this, "YouTube: Upload ausgelöst")
            PostingOrchestrator.finishPlatform(this, Prefs.STAGE_YOUTUBE)
            resetPlatformFlagsLater()
        }
    }

    private fun resetPlatformFlagsLater() {
        h.postDelayed({ platformCaptionFilled = false; platformFinalClicked = false }, 3500)
    }

    private fun ready(ms: Long = 350): Boolean {
        val n = System.currentTimeMillis()
        if (n - lastActionAt < ms) return false
        lastActionAt = n
        return true
    }

    private fun collectText(root: AccessibilityNodeInfo): String {
        val sb = StringBuilder()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            n.text?.toString()?.takeIf { it.isNotBlank() }?.let { sb.append(it).append('\n') }
            n.contentDescription?.toString()?.takeIf { it.isNotBlank() }?.let { sb.append(it).append('\n') }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return sb.toString()
    }

    private fun largestImageLikeNode(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var best: AccessibilityNodeInfo? = null
        var area = 0L
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            val cls = n.className?.toString().orEmpty()
            val desc = n.contentDescription?.toString().orEmpty().lowercase()
            val text = n.text?.toString().orEmpty().lowercase()
            val likely = cls.contains("ImageView") || desc.contains("image") || desc.contains("bild") || desc.contains("generated") || text == "image" || text == "bild"
            if (likely) {
                val r = Rect(); n.getBoundsInScreen(r)
                val a = r.width().toLong() * r.height().toLong()
                if (a > area && a > 40_000) { area = a; best = n }
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return best
    }

    private fun findBestEditable(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val found = mutableListOf<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            val cls = n.className?.toString().orEmpty()
            if (n.isEditable || cls.contains("EditText")) found += n
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return found.maxByOrNull {
            val r = Rect(); it.getBoundsInScreen(r); r.width().toLong() * r.height().toLong()
        }
    }

    private fun setText(n: AccessibilityNodeInfo, value: String): Boolean {
        val b = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, value) }
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    private fun scrollAny(root: AccessibilityNodeInfo, forward: Boolean): Boolean {
        val action = if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        val nodes = mutableListOf<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            if (n.isScrollable) nodes += n
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return nodes.asReversed().any { it.performAction(action) }
    }

    private fun clickByLabels(root: AccessibilityNodeInfo, labels: List<String>): Boolean {
        val candidates = mutableListOf<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            val t = (n.text?.toString().orEmpty() + " " + n.contentDescription?.toString().orEmpty()).trim()
            if (labels.any { label -> t.equals(label, true) || t.contains(label, true) }) candidates += n
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return candidates.asReversed().any { clickNodeOrParent(it) }
    }

    private fun clickNodeOrParent(node: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = node
        repeat(6) {
            if (n?.isClickable == true && n?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true) return true
            n = n?.parent
        }
        return false
    }

    private fun toastOnce(msg: String) {
        val now = System.currentTimeMillis()
        if (msg == lastToast && now - lastToastAt < 8_000L) return
        lastToast = msg
        lastToastAt = now
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
