package com.canjacky.autoposter

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File

object PostingOrchestrator {

    fun start(c: Context) {
        Prefs.bumpRunId(c)
        Prefs.setStatus(c, "Öffne den neuesten ChatGPT-Post …")
        Prefs.setStage(c, Prefs.STAGE_CHATGPT)
        try {
            val pi = ChatGptNotificationListener.latestChatGptIntent
            if (pi != null) {
                pi.send()
                return
            }
        } catch (_: Exception) { }
        c.packageManager.getLaunchIntentForPackage(PackageTargets.CHATGPT)?.let {
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            c.startActivity(it)
        } ?: run { Prefs.setStatus(c, "ChatGPT-App nicht gefunden") }
    }

    fun afterMediaCaptured(c: Context) {
        next(c, after = null)
    }

    fun next(c: Context, after: String?) {
        if (after == null && Prefs.isTikTok(c)) return launchTikTok(c)
        if ((after == null || after == Prefs.STAGE_TIKTOK) && Prefs.isFacebook(c)) return launchFacebook(c)
        if ((after == null || after == Prefs.STAGE_TIKTOK || after == Prefs.STAGE_FACEBOOK) && Prefs.isYouTube(c)) {
            val mime = Prefs.mediaMime(c)
            if (mime.startsWith("video/")) return launchYouTube(c, mediaUri(c))
            if (Prefs.useLatestMp4(c)) {
                val video = MediaStoreHelper.latestVideo(c)
                if (video != null) return launchYouTube(c, video)
            }
        }
        Prefs.setStage(c, Prefs.STAGE_DONE)
        Prefs.setStatus(c, "Fertig")
        launchHome(c)
    }

    private fun mediaUri(c: Context): Uri? {
        val p = Prefs.mediaPath(c)
        if (p.isBlank()) return null
        val f = File(p)
        if (!f.exists()) return null
        return FileProvider.getUriForFile(c, "${c.packageName}.fileprovider", f)
    }

    private fun share(c: Context, pkg: String, uri: Uri?, mime: String, text: String) {
        if (uri == null) {
            Prefs.setStatus(c, "Keine Mediendatei verfügbar")
            return
        }
        val i = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TEXT, text)
            clipData = android.content.ClipData.newRawUri("media", uri)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            setPackage(pkg)
        }
        try { c.startActivity(i) } catch (e: Exception) { Prefs.setStatus(c, "App nicht gefunden: $pkg") }
    }

    private fun launchTikTok(c: Context) {
        Prefs.setStage(c, Prefs.STAGE_TIKTOK)
        Prefs.setStatus(c, "TikTok wird vorbereitet …")
        share(c, PackageTargets.TIKTOK, mediaUri(c), Prefs.mediaMime(c).ifBlank { "image/*" }, Prefs.metadata(c).tiktokText())
    }

    private fun launchFacebook(c: Context) {
        Prefs.setStage(c, Prefs.STAGE_FACEBOOK)
        Prefs.setStatus(c, "Facebook wird vorbereitet …")
        share(c, PackageTargets.FACEBOOK, mediaUri(c), Prefs.mediaMime(c).ifBlank { "image/*" }, Prefs.metadata(c).facebookText())
    }

    private fun launchYouTube(c: Context, uri: Uri?) {
        Prefs.setStage(c, Prefs.STAGE_YOUTUBE)
        Prefs.setStatus(c, "YouTube Short wird vorbereitet …")
        share(c, PackageTargets.YOUTUBE, uri, "video/*", Prefs.metadata(c).youtubeText())
    }

    fun finishPlatform(c: Context, stage: String) {
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({ next(c, stage) }, 5000)
    }

    private fun launchHome(c: Context) {
        c.packageManager.getLaunchIntentForPackage(c.packageName)?.apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            c.startActivity(this)
        }
    }
}
