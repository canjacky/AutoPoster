# AutoPoster v1.1

Persönliche Android-Sideload-App für ChatGPT → TikTok/Facebook/YouTube Shorts.

## V1.1 Fixes
- Jeder neue Lauf setzt Accessibility-Zustände zuverlässig zurück.
- Aktive ChatGPT-Benachrichtigungen werden beim Verbinden des Notification Listeners berücksichtigt.
- Der Accessibility-Service sucht den `[AUTOPOST_V1]`-Block auch durch automatisches Scrollen.
- Erst nach erkannten Metadaten wird nach dem Bild gesucht.
- Bildübernahme bevorzugt Download/Speichern + MediaStore; Teilen bleibt Fallback.
- Diagnose zeigt letzte erkannte App und letzten internen Schritt.
- Testmodus bleibt standardmäßig aktiv.
