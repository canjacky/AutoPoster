# AutoPoster v1

Android-APK für einen **vom Nutzer ausdrücklich gestarteten** Posting-Workflow:

**ChatGPT → TikTok → Facebook → YouTube Shorts**

Die App verwendet **keine OpenAI API**. Sie öffnet die ChatGPT-App, versucht den jüngsten Task-Post zu lesen, übernimmt die maschinenlesbaren `[AUTOPOST_V1]`-Metadaten und versucht, das zugehörige Bild/Video über Androids Share-UI an AutoPoster zu übergeben. Anschließend werden die Medien per Share-Intent an TikTok/Facebook/YouTube geschickt; der AccessibilityService füllt die Texte und kann im Vollautomatikmodus den finalen Post-Button betätigen.

## Wichtige Realität

Android-UI-Automation ist absichtlich eine **V1 / persönliche Sideload-Lösung**. Änderungen in ChatGPT, TikTok, Facebook oder YouTube können Buttontexte oder Bildschirmabläufe ändern. Deshalb ist der **Testmodus standardmäßig aktiviert**.

## YouTube Shorts

YouTube braucht ein Video. Wenn ChatGPT nur ein Bild erzeugt, kann AutoPoster optional das **neueste MP4 aus MediaStore** verwenden. Damit das funktioniert, benötigt die App `READ_MEDIA_VIDEO`. Die App erzeugt in V1 selbst **kein Video aus dem Bild**.

## Ersteinrichtung auf dem Handy

1. APK installieren.
2. AutoPoster öffnen.
3. `Bedienungshilfe aktivieren` antippen und **AutoPoster** einschalten.
4. `ChatGPT-Benachrichtigungen erlauben` antippen und **AutoPoster ChatGPT Notification Listener** erlauben.
5. Medien-/Benachrichtigungsberechtigungen erlauben.
6. Zuerst **Testmodus** aktiviert lassen.
7. Einen aktuellen ChatGPT-Task-Post mit `[AUTOPOST_V1]` bereitstellen.
8. `JETZT POSTEN` antippen.

## Der ChatGPT-Task muss so ausgeben

```text
[AUTOPOST_V1]
[TIKTOK_TITLE]...[/TIKTOK_TITLE]
[TIKTOK_DESC]...[/TIKTOK_DESC]
[TIKTOK_TAGS]#a #b #c #d #e[/TIKTOK_TAGS]
[FACEBOOK_TITLE]...[/FACEBOOK_TITLE]
[FACEBOOK_DESC]...[/FACEBOOK_DESC]
[FACEBOOK_TAGS]#a #b #c[/FACEBOOK_TAGS]
[YOUTUBE_TITLE]...[/YOUTUBE_TITLE]
[YOUTUBE_DESC]...[/YOUTUBE_DESC]
[YOUTUBE_TAGS]#shorts #a #b[/YOUTUBE_TAGS]
[/AUTOPOST_V1]
```

Der zugehörige ChatGPT-Task wurde in diesem Chat bereits auf diese Marker umgestellt.

## Build über GitHub Actions

Workflow: `.github/workflows/build-apk.yml`

Nach erfolgreichem Lauf:

`Actions → Build APK → Artifacts → AutoPoster-debug-apk`

## Unterstützte App-Pakete

- ChatGPT: `com.openai.chatgpt`
- TikTok: `com.zhiliaoapp.musically`
- Facebook: `com.facebook.katana`
- YouTube: `com.google.android.youtube`

## Was V1 besonders robust macht

- Öffnet nach Möglichkeit die jüngste ChatGPT-Notification direkt.
- Metadaten sind per festen Markern parsebar.
- Medien werden über `ACTION_SEND` statt über fragile Galerie-Taps an Zielapps übergeben.
- Deutsch/Englisch-Buttonvarianten werden unterstützt.
- Testmodus verhindert standardmäßig den finalen Veröffentlichungs-Klick.

## Bekannte Grenzen

- ChatGPT muss das Bild/Video über einen zugänglichen `Share/Teilen`-Button anbieten. Wenn die App-Struktur diesen Button nicht via Accessibility exponiert, ist einmaliges manuelles `Teilen → AutoPoster` der Fallback; danach läuft die Plattformkette weiter.
- TikTok/Facebook/YouTube können ihre UI jederzeit verändern.
- YouTube-Beschreibung/Titel-Felder unterscheiden sich je nach App-Version; die App sucht generisch nach editierbaren Feldern.
- Automatisierte Bedienung kann gegen Store-/Plattformregeln verstoßen, insbesondere bei Veröffentlichung als allgemeine Play-Store-App. Dieses Projekt ist für persönliche Nutzung/Test/Sideload konzipiert.
